import { useEffect, useMemo, useState } from 'react';
import { auth, api } from '@appdeploy/client';
import {
  Activity,
  ArrowUpRight,
  BadgeCheck,
  BarChart3,
  Bell,
  Check,
  ChevronRight,
  CircleHelp,
  Clapperboard,
  Clock3,
  Cloud,
  Download,
  ExternalLink,
  Film,
  Flame,
  Gamepad2,
  Gauge,
  Globe2,
  LayoutDashboard,
  ListFilter,
  Loader2,
  LockKeyhole,
  LogOut,
  Menu,
  Play,
  Plus,
  Radio,
  RefreshCw,
  Search,
  Settings,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  Upload,
  Video,
  X,
  Youtube,
} from 'lucide-react';
import TopicFinder, { type TopicVideo } from './TopicFinder';
import AutoClipper from './AutoClipper';

type User = { userId: string; email?: string; name?: string; picture?: string };
type Stream = {
  id: string;
  title: string;
  channelTitle?: string;
  url: string;
  sourceType: string;
  createdAt: string;
};
type Clip = {
  id: string;
  title: string;
  category: string;
  score: number;
  hook: string;
  description: string;
  hashtags: string[];
  startTime: string;
  endTime: string;
  sourceTitle: string;
  sourceUrl: string;
  creator?: string;
  status: string;
  createdAt: string;
};
type LiveVideo = {
  videoId: string;
  title: string;
  channelTitle: string;
  thumbnail: string;
  url: string;
  publishedAt?: string;
  sourceType?: 'live' | 'popular';
  viewCount?: number;
  likeCount?: number;
  duration?: string;
  discoveredAt?: string;
};
type Overview = {
  streams: Stream[];
  clips: Clip[];
  youtubeConfigured: boolean;
  youtubeOAuthConfigured: boolean;
};

const categories = [
  'All clips',
  'Funniest moments',
  'Craziest moments',
  'Epic gameplay',
  'Fails & disasters',
  'Streamer reactions',
  'Best discoveries',
  'Insane missions',
  'Most viral potential',
  'Trending GTA 6 moments',
];

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [section, setSection] = useState('Overview');
  const [overview, setOverview] = useState<Overview>({
    streams: [],
    clips: [],
    youtubeConfigured: false,
  });
  const [live, setLive] = useState<LiveVideo[]>([]);
  const [creatorFilter, setCreatorFilter] = useState('');
  const [loading, setLoading] = useState(false);
  const [discovering, setDiscovering] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [notice, setNotice] = useState('');
  const [filter, setFilter] = useState('All clips');
  const [query, setQuery] = useState('');
  const [showMoment, setShowMoment] = useState(false);
  const [momentBusy, setMomentBusy] = useState(false);
  const [streamBusy, setStreamBusy] = useState(false);
  const [moment, setMoment] = useState({
    sourceTitle: '',
    sourceUrl: '',
    creator: '',
    startTime: '00:00',
    endTime: '00:35',
    notes: '',
  });
  const [streamUrl, setStreamUrl] = useState('');
  const [youtubeAccessToken, setYoutubeAccessToken] = useState('');
  const [youtubeExpiresAt, setYoutubeExpiresAt] = useState(0);
  const [youtubeConnecting, setYoutubeConnecting] = useState(false);
  const [driveAccessToken, setDriveAccessToken] = useState('');
  const [driveFiles, setDriveFiles] = useState<Array<{ id: string; name: string; mimeType: string; modifiedTime: string; size: string; webViewLink: string; isVideo: boolean }>>([]);
  const [driveConnecting, setDriveConnecting] = useState(false);
  const [driveLoading, setDriveLoading] = useState(false);
  const [shortBusy, setShortBusy] = useState(false);
  const [shortInput, setShortInput] = useState({
    sourceTitle: '',
    creator: '',
    startTime: '00:00',
    endTime: '00:45',
    transcript: '',
  });
  const [shortPlan, setShortPlan] = useState<null | {
    viralScore: number;
    hook: string;
    title: string;
    description: string;
    hashtags: string[];
    editNotes: string[];
    captions: Array<{ start: number; end: number; text: string }>;
  }>(null);


  async function loadData() {
    setLoading(true);
    setErrorMessage('');
    try {
      const { data } = await api.get('/api/overview');
      setOverview(data);
    } catch (e) {
      setErrorMessage(
        e instanceof Error ? e.message : 'Could not load your workspace.'
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    const state = params.get('state');
    const oauthError = params.get('error');
    if (!code && !oauthError) return;

    window.history.replaceState({}, document.title, window.location.pathname);
    if (oauthError) {
      setYoutubeConnecting(false);
      setErrorMessage('YouTube authorization was cancelled or denied. You can try connecting again.');
      return;
    }
    if (!code || !state) {
      setYoutubeConnecting(false);
      setErrorMessage('Google returned an incomplete authorization response. Please reconnect.');
      return;
    }

    setYoutubeConnecting(true);
    api.post('/api/google/oauth/exchange', { code, state })
      .then(async ({ data }) => {
        if (!data.access_token) throw new Error('Google did not return an access token.');
        if (data.integration === 'drive') {
          setDriveAccessToken(data.access_token);
          setDriveLoading(true);
          const { data: inbox } = await api.post('/api/drive/inbox', { accessToken: data.access_token });
          setDriveFiles(inbox.files || []);
          setNotice('Google Drive is connected for this session. The Ready to Clip folder is readable; background syncing still needs a secure long-lived connection.');
        } else {
          setYoutubeAccessToken(data.access_token);
          setYoutubeExpiresAt(Date.now() + Number(data.expires_in || 3600) * 1000);
          setNotice('YouTube upload permission connected. Public GTA 6 discovery still uses the separate YouTube Data API key.');
          api.post('/api/youtube/discoveries/refresh', {})
            .then(({ data: discovery }) => {
              setLive(discovery.items || []);
              if (!discovery.configured) {
                setNotice('YouTube upload is connected. Add YOUTUBE_API_KEY in AppDeploy secrets for public-video search.');
              }
            })
            .catch(() => undefined);
        }
      })
      .catch(e => {
        setErrorMessage(e instanceof Error ? e.message : 'Google authorization could not be completed. Please reconnect.');
      })
      .finally(() => {
        setYoutubeConnecting(false);
        setDriveConnecting(false);
        setDriveLoading(false);
      });
  }, []);

  useEffect(() => {
    let active = true;
    auth
      .getUser()
      .then(restored => {
        if (!active) return;
        setUser(restored);
        setAuthReady(true);
        if (restored) {
          api
            .get('/api/overview')
            .then(({ data }) => {
              if (active) setOverview(data);
            })
            .catch(e => {
              if (active)
                setErrorMessage(
                  e instanceof Error
                    ? e.message
                    : 'Could not load your workspace.'
                );
            });
        }
      })
      .catch(() => {
        if (active) {
          setAuthReady(true);
          setErrorMessage('Sign-in could not be restored. Please try again.');
        }
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!user || section !== 'Live discovery') return;
    let active = true;
    api.get('/api/youtube/discoveries')
      .then(async ({ data }) => {
        if (!active) return;
        const savedItems = data.items || [];
        setLive(savedItems);
        setOverview(old => ({ ...old, youtubeConfigured: Boolean(data.configured) }));
        const newest = savedItems.reduce((latest: number, item: LiveVideo & { discoveredAt?: string }) =>
          Math.max(latest, item.discoveredAt ? new Date(item.discoveredAt).getTime() : 0), 0);
        const stale = !savedItems.length || Date.now() - newest > 45 * 60 * 1000;
        if (data.configured && stale) {
          setDiscovering(true);
          try {
            const refreshed = await api.post('/api/youtube/discoveries/refresh', {});
            if (active) setLive(refreshed.data.items || []);
          } catch (e) {
            if (active) setErrorMessage(e instanceof Error ? e.message : 'Automatic YouTube refresh failed.');
          } finally {
            if (active) setDiscovering(false);
          }
        }
      })
      .catch(e => {
        if (active) setErrorMessage(e instanceof Error ? e.message : 'Could not load automatic discoveries.');
      });
    return () => { active = false; };
  }, [user, section]);

  async function signIn() {
    setErrorMessage('');
    try {
      await auth.signInWithRedirect();
    } catch (e) {
      setErrorMessage(
        e instanceof Error ? e.message : 'Google sign-in failed. Please retry.'
      );
    }
  }

  async function connectYouTube() {
    setYoutubeConnecting(true);
    setErrorMessage('');
    try {
      const { data } = await api.get('/api/youtube/oauth/start');
      if (!data.url) throw new Error('Google authorization URL was not returned.');
      window.location.assign(data.url);
    } catch (e) {
      setYoutubeConnecting(false);
      setErrorMessage(e instanceof Error ? e.message : 'Could not start YouTube authorization.');
    }
  }

  async function connectDrive() {
    setDriveConnecting(true);
    setErrorMessage('');
    try {
      const { data } = await api.get('/api/drive/oauth/start');
      if (!data.url) throw new Error('Google Drive authorization URL was not returned.');
      window.location.assign(data.url);
    } catch (e) {
      setDriveConnecting(false);
      setErrorMessage(e instanceof Error ? e.message : 'Could not start Google Drive authorization.');
    }
  }

  async function refreshDriveInbox() {
    if (!driveAccessToken) return;
    setDriveLoading(true);
    setErrorMessage('');
    try {
      const { data } = await api.post('/api/drive/inbox', { accessToken: driveAccessToken });
      setDriveFiles(data.files || []);
      setNotice('Ready to Clip inbox refreshed.');
    } catch (e) {
      setErrorMessage(e instanceof Error ? e.message : 'Could not read the Ready to Clip folder.');
    } finally {
      setDriveLoading(false);
    }
  }

  async function signOut() {
    await auth.signOut();
    setUser(null);
    setOverview({ streams: [], clips: [], youtubeConfigured: false });
    setLive([]);
  }

  async function discoverLive() {
    setDiscovering(true);
    setErrorMessage('');
    try {
      const { data } = await api.post('/api/youtube/discoveries/refresh', { creator: creatorFilter.trim() });
      if (!data.configured) {
        setNotice(
          'Add a YouTube Data API key in AppDeploy secrets to enable live stream discovery. No sample streams are shown as real results.'
        );
        setOverview(old => ({ ...old, youtubeConfigured: false }));
      } else {
        setLive(data.items || []);
        setOverview(old => ({ ...old, youtubeConfigured: true }));
        setNotice(
          (data.items || []).length
            ? 'Automatic GTA 6 discovery refreshed with public videos and livestreams.'
            : 'No matching public GTA 6 videos or livestreams were returned. The scheduled search will try again.'
        );
      }
    } catch (e) {
      setErrorMessage(
        e instanceof Error ? e.message : 'Live discovery failed.'
      );
    } finally {
      setDiscovering(false);
    }
  }

  async function addStream(url: string, title?: string) {
    setStreamBusy(true);
    setErrorMessage('');
    try {
      await api.post('/api/streams', {
        url,
        title: title || url,
        sourceType: 'creator-authorized source',
      });
      setStreamUrl('');
      setNotice(
        'Source added to your monitoring list. Only footage you have permission to process should be used.'
      );
      await loadData();
    } catch (e) {
      setErrorMessage(e instanceof Error ? e.message : 'Could not add source.');
    } finally {
      setStreamBusy(false);
    }
  }

  async function analyzeMoment(event: React.FormEvent) {
    event.preventDefault();
    setMomentBusy(true);
    setErrorMessage('');
    try {
      await api.post('/api/analyze', moment);
      setShowMoment(false);
      setMoment({
        sourceTitle: '',
        sourceUrl: '',
        creator: '',
        startTime: '00:00',
        endTime: '00:35',
        notes: '',
      });
      setNotice(
        'AI clip concept created and added to your review queue. Add authorized footage before publishing.'
      );
      await loadData();
      setSection('Clip library');
    } catch (e) {
      setErrorMessage(
        e instanceof Error ? e.message : 'AI analysis failed. Please retry.'
      );
    } finally {
      setMomentBusy(false);
    }
  }

  async function prepareShort(event: React.FormEvent) {
    event.preventDefault();
    setShortBusy(true);
    setErrorMessage('');
    setShortPlan(null);
    try {
      const { data } = await api.post('/api/shorts/prepare', shortInput);
      setShortPlan(data.plan);
      setNotice('Shorts editing blueprint generated. Review it before using authorised footage.');
    } catch (e) {
      setErrorMessage(e instanceof Error ? e.message : 'Could not prepare this Short.');
    } finally {
      setShortBusy(false);
    }
  }

  function downloadCaptions() {
    if (!shortPlan?.captions?.length) return;
    const stamp = (seconds: number) => {
      const ms = Math.max(0, Math.round(seconds * 1000));
      const hours = Math.floor(ms / 3600000);
      const minutes = Math.floor((ms % 3600000) / 60000);
      const secs = Math.floor((ms % 60000) / 1000);
      const millis = ms % 1000;
      return [hours, minutes, secs].map(value => String(value).padStart(2, '0')).join(':') + ',' + String(millis).padStart(3, '0');
    };
    const srt = shortPlan.captions.map((line, index) =>
      (index + 1) + '\\n' + stamp(line.start) + ' --> ' + stamp(line.end) + '\\n' + line.text
    ).join('\\n\\n');
    const blob = new Blob([srt], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = 'clipforge-captions.srt';
    anchor.click();
    URL.revokeObjectURL(url);
  }

  async function approveClip(id: string) {
    try {
      await api.post('/api/clips/' + id + '/approve', {});
      setNotice('Clip marked as approved for your next publishing step.');
      await loadData();
    } catch (e) {
      setErrorMessage(
        e instanceof Error ? e.message : 'Could not update clip.'
      );
    }
  }

  const visibleClips = useMemo(
    () =>
      overview.clips.filter(clip => {
        const categoryMatch =
          filter === 'All clips' ||
          (filter === 'Most viral potential'
            ? clip.score >= 80
            : clip.category.toLowerCase() === filter.toLowerCase());
        const textMatch =
          !query ||
          (clip.title + ' ' + clip.description + ' ' + clip.category)
            .toLowerCase()
            .includes(query.toLowerCase());
        return categoryMatch && textMatch;
      }),
    [overview.clips, filter, query]
  );

  if (!authReady)
    return (
      <div className="boot">
        <div className="brand-mark">
          <Gamepad2 size={24} />
        </div>
        <Loader2 className="spin" size={22} />
        <span>Preparing your studio…</span>
      </div>
    );

  if (!user)
    return (
      <div className="login-shell">
        <div className="login-art">
          <div className="art-grid" />
          <div className="art-glow" />
          <div className="art-copy">
            <span className="eyebrow">
              <span className="live-dot" /> CREATOR INTELLIGENCE
            </span>
            <h1>
              Find the moment.
              <br />
              <em>Make it viral.</em>
            </h1>
            <p>
              Your AI-assisted command center for discovering GTA 6 live
              content, shaping standout moments and preparing YouTube Shorts.
            </p>
            <div className="art-stats">
              <div>
                <strong>01</strong>
                <small>Discover</small>
              </div>
              <div>
                <strong>02</strong>
                <small>Analyze</small>
              </div>
              <div>
                <strong>03</strong>
                <small>Publish</small>
              </div>
            </div>
          </div>
          <div className="art-watermark">VI / VI</div>
        </div>
        <div className="login-panel">
          <div className="brand">
            <div className="brand-mark">
              <Gamepad2 size={22} />
            </div>
            <div>
              <b>CLIPFORGE</b>
              <small>GTA 6 VIRAL STUDIO</small>
            </div>
          </div>
          <div className="login-content">
            <span className="eyebrow">YOUR CREATOR WORKSPACE</span>
            <h2>
              Turn great gameplay
              <br />
              into great content.
            </h2>
            <p>
              Sign in to manage your stream sources, AI clip ideas and
              publishing review queue.
            </p>
            <button className="google-button" onClick={signIn}>
              <GoogleGlyph /> Continue with Google <ArrowUpRight size={17} />
            </button>
            {errorMessage && <div className="alert error">{errorMessage}</div>}
            <div className="secure-note">
              <LockKeyhole size={14} /> Secure sign-in. Your workspace is
              private to your account.
            </div>
          </div>
          <div className="login-foot">
            Built for the GTA 6 creator community <span>•</span> Launch target
            19 Nov 2026
          </div>
        </div>
      </div>
    );

  const nav = [
    { name: 'Overview', icon: LayoutDashboard },
    { name: 'Live discovery', icon: Radio },
    { name: 'Topic Finder', icon: Search },
    { name: 'Auto Clipper', icon: Video },
    { name: 'Clip library', icon: Clapperboard },
    { name: 'AI Studio', icon: Sparkles },
    { name: 'Sources', icon: Globe2 },
    { name: 'Publishing', icon: Youtube },
    { name: 'Settings', icon: Settings },
  ];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand side-brand">
          <div className="brand-mark">
            <Gamepad2 size={21} />
          </div>
          <div>
            <b>CLIPFORGE</b>
            <small>GTA 6 VIRAL STUDIO</small>
          </div>
        </div>
        <div className="workspace-label">WORKSPACE</div>
        <nav>
          {nav.map(item => (
            <button
              key={item.name}
              className={'nav-item ' + (section === item.name ? 'active' : '')}
              onClick={() => setSection(item.name)}
            >
              <item.icon size={18} />
              <span>{item.name}</span>
              {item.name === 'Clip library' && overview.clips.length > 0 && (
                <small>{overview.clips.length}</small>
              )}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="launch-card">
            <div className="launch-icon">
              <Flame size={17} />
            </div>
            <b>Launch watch</b>
            <strong>19 NOV 2026</strong>
            <p>Get your workflow ready before launch day.</p>
          </div>
          <div className="profile-row">
            {user.picture ? (
              <img src={user.picture} alt="" />
            ) : (
              <div className="avatar">
                {(user.name || user.email || 'U').slice(0, 1).toUpperCase()}
              </div>
            )}
            <div className="profile-info">
              <b>{user.name || 'Creator'}</b>
              <small>{user.email || 'Google account'}</small>
            </div>
            <button className="icon-button" title="Sign out" onClick={signOut}>
              <LogOut size={16} />
            </button>
          </div>
        </div>
      </aside>
      <main className="main-area">
        <header className="topbar">
          <div className="breadcrumb">
            <span>Workspace</span>
            <ChevronRight size={14} />
            <b>{section}</b>
          </div>
          <div className="top-actions">
            <span className="date-pill">
              <span className="live-dot" /> LAUNCH WATCH ACTIVE
            </span>
            <button
              className="icon-button"
              onClick={loadData}
              title="Refresh workspace"
            >
              <RefreshCw size={17} />
            </button>
            <div className="top-avatar">
              {(user.name || user.email || 'U').slice(0, 1).toUpperCase()}
            </div>
          </div>
        </header>
        <div className="page-content">
          {errorMessage && (
            <div className="alert error">
              <span>{errorMessage}</span>
              <button onClick={() => setErrorMessage('')}>
                <X size={15} />
              </button>
            </div>
          )}
          {notice && (
            <div className="alert notice">
              <Check size={16} />
              <span>{notice}</span>
              <button onClick={() => setNotice('')}>
                <X size={15} />
              </button>
            </div>
          )}
          {section === 'Overview' && (
            <>
              <div className="page-heading">
                <div>
                  <span className="eyebrow">
                    THURSDAY, 19 NOVEMBER 2026 · LAUNCH DAY TARGET
                  </span>
                  <h1>
                    Creator command center<span>.</span>
                  </h1>
                  <p>Your GTA 6 moment-finding operation, all in one place.</p>
                </div>
                <button
                  className="primary-button"
                  onClick={() => setShowMoment(true)}
                >
                  <Sparkles size={17} /> Analyze a moment
                </button>
              </div>
              <div className="stats-grid">
                <Stat
                  icon={Radio}
                  label="Saved sources"
                  value={overview.streams.length.toString()}
                  sub="Creator-authorized sources"
                  tone="purple"
                />
                <Stat
                  icon={Clapperboard}
                  label="AI clip concepts"
                  value={overview.clips.length.toString()}
                  sub="In your clip library"
                  tone="blue"
                />
                <Stat
                  icon={BadgeCheck}
                  label="Approved clips"
                  value={overview.clips
                    .filter(c => c.status === 'approved')
                    .length.toString()}
                  sub="Ready for your next step"
                  tone="green"
                />
                <Stat
                  icon={Youtube}
                  label="Published Shorts"
                  value="—"
                  sub="YouTube publishing not connected"
                  tone="red"
                />
              </div>
              <div className="content-grid">
                <section className="panel live-panel">
                  <div className="panel-head">
                    <div>
                      <span className="eyebrow">DISCOVERY ENGINE</span>
                      <h3>Live GTA 6 streams</h3>
                    </div>
                    <button
                      className="text-button"
                      onClick={() => setSection('Live discovery')}
                    >
                      Open discovery <ArrowUpRight size={15} />
                    </button>
                  </div>
                  <div className="empty-state compact">
                    <div className="empty-icon">
                      <Radio size={23} />
                    </div>
                    <b>
                      {overview.youtubeConfigured
                        ? 'No live results loaded yet'
                        : 'Connect stream discovery'}
                    </b>
                    <p>
                      Use the official YouTube Data API to find public GTA 6
                      livestreams. Discovery requires your API key.
                    </p>
                    <button
                      className="secondary-button"
                      onClick={() => {
                        setSection('Live discovery');
                        discoverLive();
                      }}
                    >
                      <Search size={15} /> Find live streams
                    </button>
                  </div>
                </section>
                <section className="panel score-panel">
                  <div className="panel-head">
                    <div>
                      <span className="eyebrow">AI PERFORMANCE SIGNAL</span>
                      <h3>Top clip opportunities</h3>
                    </div>
                    <Gauge size={19} className="muted" />
                  </div>
                  {overview.clips.length ? (
                    overview.clips
                      .slice()
                      .sort((a, b) => b.score - a.score)
                      .slice(0, 3)
                      .map(clip => (
                        <div className="opportunity" key={clip.id}>
                          <div className="score-ring">{clip.score}</div>
                          <div className="op-copy">
                            <b>{clip.title}</b>
                            <small>{clip.category}</small>
                          </div>
                          <ChevronRight size={16} />
                        </div>
                      ))
                  ) : (
                    <div className="empty-mini">
                      <Sparkles size={18} />
                      <span>
                        Your highest-scoring moments will appear here.
                      </span>
                    </div>
                  )}
                </section>
              </div>
              <section className="panel">
                <div className="panel-head">
                  <div>
                    <span className="eyebrow">YOUR WORKFLOW</span>
                    <h3>From livestream to Short</h3>
                  </div>
                  <span className="status-chip">REVIEW FIRST</span>
                </div>
                <div className="workflow">
                  {[
                    {
                      n: '01',
                      t: 'Discover',
                      d: 'Find public live GTA 6 streams',
                      i: Search,
                    },
                    {
                      n: '02',
                      t: 'Capture legally',
                      d: 'Use footage you are authorized to process',
                      i: ShieldCheck,
                    },
                    {
                      n: '03',
                      t: 'AI analyze',
                      d: 'Score and categorize standout moments',
                      i: Sparkles,
                    },
                    {
                      n: '04',
                      t: 'Review & publish',
                      d: 'Approve before any YouTube upload',
                      i: Youtube,
                    },
                  ].map(x => (
                    <div className="workflow-step" key={x.n}>
                      <div className="workflow-icon">
                        <x.i size={18} />
                      </div>
                      <small>{x.n}</small>
                      <b>{x.t}</b>
                      <p>{x.d}</p>
                    </div>
                  ))}
                </div>
              </section>
            </>
          )}
          {section === 'Live discovery' && (
            <>
              <div className="page-heading">
                <div>
                  <span className="eyebrow">PUBLIC STREAM SEARCH</span>
                  <h1>
                    Automatic discovery<span>.</span>
                  </h1>
                  <p>
                    ClipForge automatically collects public GTA 6 videos and livestreams. Add a creator name only when you want to narrow the search.
                  </p>
                </div>
                <button
                  className="primary-button"
                  onClick={discoverLive}
                  disabled={discovering}
                >
                  {discovering ? (
                    <Loader2 className="spin" size={17} />
                  ) : (
                    <RefreshCw size={17} />
                  )}{' '}
                  Refresh streams
                </button>
              </div>
              <div className="panel add-source">
                <div>
                  <span className="eyebrow">OPTIONAL CREATOR FILTER</span>
                  <h3>Focus on a specific creator</h3>
                  <p>Leave this blank for all GTA 6 discovery. You never need to paste a video or livestream link.</p>
                </div>
                <form onSubmit={e => { e.preventDefault(); discoverLive(); }}>
                  <input value={creatorFilter} onChange={e => setCreatorFilter(e.target.value)} placeholder="Creator or channel name (optional)" />
                  <button className="primary-button" disabled={discovering}><Search size={16} /> Search creator</button>
                </form>
              </div>
              <div className="panel discovery-callout">
                <div className="callout-icon">
                  <Radio size={22} />
                </div>
                <div>
                  <b>Automatic discovery runs in the background</b>
                  <p>
                    ClipForge checks public GTA 6 livestreams and the most-viewed public GTA 6 videos every hour, then ranks results by current view count. The screen also refreshes automatically when its saved results are older than 45 minutes. Connecting upload permission is separate from public search: YOUTUBE_API_KEY must be configured in AppDeploy secrets. Public discovery does not grant permission to download or republish footage. Actual clip rendering still requires an authorised source video file.
                  </p>
                </div>
              </div>
              {live.length ? (
                <div className="live-list">
                  {live.map(item => (
                    <div className="live-card" key={item.videoId}>
                      <img src={item.thumbnail} alt="Stream thumbnail" />
                      <div className="live-info">
                        <span className="live-label">
                          <span className="live-dot" /> {item.sourceType === 'live' ? 'LIVE NOW' : 'MOST VIEWED'}
                        </span>
                        <b>{item.title}</b>
                        <small>{item.channelTitle}</small>
                        <small>{new Intl.NumberFormat('en-ZA', { notation: 'compact', maximumFractionDigits: 1 }).format(item.viewCount || 0)} views · {item.publishedAt ? new Date(item.publishedAt).toLocaleDateString() : 'Date unavailable'}</small>
                        <a href={item.url} target="_blank" rel="noreferrer">
                          Open on YouTube <ExternalLink size={13} />
                        </a>
                      </div>
                      <button
                        className="secondary-button"
                        onClick={() => addStream(item.url, item.title)}
                        disabled={streamBusy}
                      >
                        <Plus size={15} /> Save source
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="panel empty-state">
                  <div className="empty-icon">
                    <Radio size={25} />
                  </div>
                  <h3>
                    {discovering
                      ? 'Searching YouTube…'
                      : 'Ready to find live streams'}
                  </h3>
                  <p>
                    {overview.youtubeConfigured
                      ? 'No matching live streams are currently displayed.'
                      : 'Add YOUTUBE_API_KEY in AppDeploy secrets. Your YouTube upload connection does not provide this public-search API key.'}
                  </p>
                  <button
                    className="primary-button"
                    onClick={discoverLive}
                    disabled={discovering}
                  >
                    <Search size={16} /> Search YouTube
                  </button>
                </div>
              )}
            </>
          )}
          {section === 'Topic Finder' && (
            <TopicFinder
              onUse={(item: TopicVideo) => {
                setShortInput(old => ({
                  ...old,
                  sourceTitle: item.title,
                  creator: item.channelTitle,
                }));
                setSection('AI Studio');
                setNotice('Video details added to AI Studio. Add a transcript or moment notes, and only process footage you own or are authorised to use.');
              }}
            />
          )}
          {section === 'Auto Clipper' && (
            <AutoClipper
              sourceTitle={shortInput.sourceTitle}
              initialStart={shortInput.startTime}
              initialEnd={shortInput.endTime}
              captions={shortPlan?.captions || []}
              initialTranscript={shortInput.transcript}
            />
          )}
          {section === 'Clip library' && (
            <>
              <div className="page-heading">
                <div>
                  <span className="eyebrow">AI-ASSISTED MOMENT WORKBENCH</span>
                  <h1>
                    Clip library<span>.</span>
                  </h1>
                  <p>
                    Rank, refine and review the moments worth turning into
                    Shorts.
                  </p>
                </div>
                <button
                  className="primary-button"
                  onClick={() => setShowMoment(true)}
                >
                  <Plus size={17} /> New clip concept
                </button>
              </div>
              <div className="library-toolbar">
                <div className="search-box">
                  <Search size={16} />
                  <input
                    placeholder="Search clip ideas…"
                    value={query}
                    onChange={e => setQuery(e.target.value)}
                  />
                </div>
                <div className="filter-select">
                  <ListFilter size={15} />
                  <select
                    value={filter}
                    onChange={e => setFilter(e.target.value)}
                  >
                    {categories.map(c => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </div>
              </div>
              {visibleClips.length ? (
                <div className="clip-grid">
                  {visibleClips.map(clip => (
                    <article className="clip-card" key={clip.id}>
                      <div className="clip-visual">
                        <div className="clip-play">
                          <Play size={19} fill="currentColor" />
                        </div>
                        <span className="clip-score">
                          <Flame size={13} />
                          {clip.score}/100
                        </span>
                        <span className="clip-duration">
                          {clip.startTime} – {clip.endTime}
                        </span>
                      </div>
                      <div className="clip-body">
                        <span className="category-label">{clip.category}</span>
                        <h3>{clip.title}</h3>
                        <p>{clip.hook}</p>
                        <div className="clip-meta">
                          <span>
                            <Clock3 size={13} />
                            {clip.startTime}–{clip.endTime}
                          </span>
                          <span className={'status-chip ' + clip.status}>
                            {clip.status === 'approved'
                              ? 'APPROVED'
                              : 'NEEDS REVIEW'}
                          </span>
                        </div>
                        <div className="clip-actions">
                          <button
                            className="secondary-button"
                            onClick={() =>
                              navigator.clipboard?.writeText(
                                clip.title +
                                  '\n' +
                                  clip.description +
                                  '\n' +
                                  clip.hashtags.join(' ')
                              )
                            }
                          >
                            <Download size={14} /> Copy metadata
                          </button>
                          {clip.status !== 'approved' && (
                            <button
                              className="approve-button"
                              onClick={() => approveClip(clip.id)}
                            >
                              <Check size={14} /> Approve
                            </button>
                          )}
                        </div>
                      </div>
                    </article>
                  ))}
                </div>
              ) : (
                <div className="panel empty-state">
                  <div className="empty-icon">
                    <Film size={25} />
                  </div>
                  <h3>No clip concepts yet</h3>
                  <p>
                    Add a moment description from footage you are authorized to
                    use. AI will create a category, hook, title and potential
                    score.
                  </p>
                  <button
                    className="primary-button"
                    onClick={() => setShowMoment(true)}
                  >
                    <Sparkles size={16} /> Analyze first moment
                  </button>
                </div>
              )}
            </>
          )}
          {section === 'AI Studio' && (
            <>
              <div className="page-heading">
                <div>
                  <span className="eyebrow">VIRAL MOMENT HUNTER + SHORTS EDITOR</span>
                  <h1>AI Studio<span>.</span></h1>
                  <p>Rank a moment, shape the story and prepare phone-first captions and editing notes.</p>
                </div>
                <span className="status-chip">AI WORKFLOW</span>
              </div>
              <div className="panel discovery-callout">
                <div className="callout-icon"><Sparkles size={21} /></div>
                <div>
                  <b>Viral Moment Hunter</b>
                  <p>Use a transcript or detailed notes from footage you own or are authorised to process. AI scores the moment and builds a Shorts-ready edit plan.</p>
                </div>
              </div>
              <form className="panel moment-modal" onSubmit={prepareShort}>
                <div className="modal-head">
                  <div>
                    <span className="eyebrow">STEP 01 · SOURCE CONTEXT</span>
                    <h2>Find the moment</h2>
                    <p>Paste a transcript or describe what happens. No public-video download is performed.</p>
                  </div>
                </div>
                <label>Video or stream title
                  <input value={shortInput.sourceTitle} onChange={e => setShortInput(old => ({ ...old, sourceTitle: e.target.value }))} placeholder="GTA 6 livestream — wild police chase" required />
                </label>
                <label>Creator (optional)
                  <input value={shortInput.creator} onChange={e => setShortInput(old => ({ ...old, creator: e.target.value }))} placeholder="Creator name" />
                </label>
                <div className="form-two">
                  <label>Clip starts at
                    <input value={shortInput.startTime} onChange={e => setShortInput(old => ({ ...old, startTime: e.target.value }))} />
                  </label>
                  <label>Clip ends at
                    <input value={shortInput.endTime} onChange={e => setShortInput(old => ({ ...old, endTime: e.target.value }))} />
                  </label>
                </div>
                <label>Transcript or detailed moment notes
                  <textarea rows={7} value={shortInput.transcript} onChange={e => setShortInput(old => ({ ...old, transcript: e.target.value }))} placeholder="Describe the action, reactions and dialogue in order. Include timestamps if available…" required />
                </label>
                <button className="primary-button full-button" disabled={shortBusy}>
                  {shortBusy ? <Loader2 className="spin" size={16} /> : <Sparkles size={16} />}
                  {shortBusy ? 'Analysing moment…' : 'Hunt moment & build Shorts plan'}
                </button>
              </form>
              {shortPlan && (
                <div className="panel">
                  <div className="panel-head">
                    <div>
                      <span className="eyebrow">STEP 02 · AI SHORTS EDITOR</span>
                      <h3>{shortPlan.title}</h3>
                    </div>
                    <span className="count-pill">{shortPlan.viralScore}/100 viral score</span>
                  </div>
                  <p><strong>Opening hook:</strong> {shortPlan.hook}</p>
                  <p>{shortPlan.description}</p>
                  <div className="setting-row">
                    <div><b>Vertical format</b><small>9:16 framing · keep key action and reactions in the safe centre</small></div>
                    <span className="status-chip">SHORTS</span>
                  </div>
                  <h3>Editing direction</h3>
                  <ul>{shortPlan.editNotes.map((note, index) => <li key={index}>{note}</li>)}</ul>
                  <h3>Timed captions</h3>
                  <div className="caption-list">
                    {shortPlan.captions.map((line, index) => (
                      <div className="source-row" key={index}>
                        <span className="count-pill">{line.start.toFixed(1)}s–{line.end.toFixed(1)}s</span>
                        <b>{line.text}</b>
                      </div>
                    ))}
                  </div>
                  <div className="clip-actions">
                    <button className="secondary-button" type="button" onClick={downloadCaptions}><Download size={14} /> Download SRT captions</button>
                    <button className="secondary-button" type="button" onClick={() => navigator.clipboard?.writeText(shortPlan.title + '\\n' + shortPlan.hook + '\\n' + shortPlan.description + '\\n' + shortPlan.hashtags.join(' '))}><Download size={14} /> Copy Shorts metadata</button>
                  </div>
                  <button className="primary-button full-button" type="button" onClick={() => setSection('Auto Clipper')}>
                    <Video size={15} /> Open Auto Clipper to render MP4
                  </button>
                  <div className="modal-note"><ShieldCheck size={15} /> This is an editing blueprint. Auto Clipper renders an MP4 from an authorised local video file and the selected time range.</div>
                </div>
              )}
            </>
          )}
          {section === 'Sources' && (
            <>
              <div className="page-heading">
                <div>
                  <span className="eyebrow">AUTHORIZED SOURCE LIST</span>
                  <h1>
                    Stream sources<span>.</span>
                  </h1>
                  <p>
                    Keep track of channels and videos you have permission to
                    process.
                  </p>
                </div>
              </div>
              <div className="panel add-source">
                <div>
                  <span className="eyebrow">
                    ADD A CREATOR-AUTHORIZED SOURCE
                  </span>
                  <h3>Save a stream or channel URL</h3>
                  <p>
                    Only add sources where you own the content or have
                    permission to clip and republish it.
                  </p>
                </div>
                <form
                  onSubmit={e => {
                    e.preventDefault();
                    if (streamUrl.trim()) addStream(streamUrl.trim());
                  }}
                >
                  <input
                    value={streamUrl}
                    onChange={e => setStreamUrl(e.target.value)}
                    placeholder="https://www.youtube.com/@channel or video URL"
                    required
                  />
                  <button className="primary-button" disabled={streamBusy}>
                    <Plus size={16} /> Add source
                  </button>
                </form>
              </div>
              <div className="panel table-panel">
                <div className="panel-head">
                  <h3>Saved sources</h3>
                  <span className="count-pill">{overview.streams.length}</span>
                </div>
                {overview.streams.length ? (
                  overview.streams.map(s => (
                    <div className="source-row" key={s.id}>
                      <div className="source-icon">
                        <Youtube size={18} />
                      </div>
                      <div className="source-copy">
                        <b>{s.title}</b>
                        <small>{s.url}</small>
                      </div>
                      <span className="status-chip">SAVED</span>
                      <a href={s.url} target="_blank" rel="noreferrer">
                        <ExternalLink size={16} />
                      </a>
                    </div>
                  ))
                ) : (
                  <div className="empty-mini">
                    <Globe2 size={18} />
                    No sources saved yet.
                  </div>
                )}
              </div>
            </>
          )}
          {section === 'Publishing' && (
            <>
              <div className="page-heading">
                <div>
                  <span className="eyebrow">YOUTUBE SHORTS WORKFLOW</span>
                  <h1>
                    Publishing center<span>.</span>
                  </h1>
                  <p>Review every clip before it leaves your workspace.</p>
                </div>
                <span className="status-chip">MANUAL APPROVAL ON</span>
              </div>
              <div className="panel">
                <div className="panel-head">
                  <div>
                    <span className="eyebrow">AUTOMATIC FOOTAGE INBOX</span>
                    <h3>Google Drive · Ready to Clip</h3>
                    <p>Connect the private folder you created. ClipForge will list authorised footage here; it will not download or republish arbitrary YouTube videos.</p>
                  </div>
                  <Cloud size={22} />
                </div>
                <div className="publish-state">
                  <span className="state-dot" /> {driveAccessToken ? 'Drive folder connected for this session' : 'Google Drive not connected'}
                </div>
                <div className="action-row">
                  <button className="primary-button" onClick={connectDrive} disabled={driveConnecting}>
                    {driveConnecting ? <Loader2 className="spin" size={16} /> : <Cloud size={16} />}
                    {driveConnecting ? 'Connecting…' : 'Connect Google Drive'}
                  </button>
                  {driveAccessToken && (
                    <button className="secondary-button" onClick={refreshDriveInbox} disabled={driveLoading}>
                      {driveLoading ? <Loader2 className="spin" size={16} /> : <RefreshCw size={16} />}
                      Refresh inbox
                    </button>
                  )}
                </div>
                {driveAccessToken && (
                  <>
                    <small className="muted-note">Session-only access: this connection expires when the Google access token expires or this page session ends. We are validating folder access before enabling background automation.</small>
                    <div className="source-list">
                      {driveFiles.length ? driveFiles.map(file => (
                        <div className="source-row" key={file.id}>
                          <div>
                            <b>{file.name}</b>
                            <small>{file.isVideo ? 'Video file' : file.mimeType} · {file.modifiedTime ? new Date(file.modifiedTime).toLocaleString() : 'Date unavailable'}</small>
                          </div>
                          {file.webViewLink && <a href={file.webViewLink} target="_blank" rel="noreferrer">Open <ExternalLink size={13} /></a>}
                        </div>
                      )) : <div className="empty-mini"><Film size={18} /> {driveLoading ? 'Loading folder…' : 'No files found in Ready to Clip yet.'}</div>}
                    </div>
                  </>
                )}
              </div>
              <div className="panel publish-hero">
                <div className="publish-icon">
                  <Youtube size={28} />
                </div>
                <div>
                  <span className="eyebrow">YOUTUBE CHANNEL CONNECTION</span>
                  <h2>Connect your publishing account</h2>
                  <p>
                    Google sign-in secures your ClipForge workspace. YouTube
                    upload access is a separate Google OAuth permission and must
                    be configured before direct publishing can be enabled.
                  </p>
                  <div className="publish-state">
                    <span className="state-dot" /> {youtubeAccessToken && Date.now() < youtubeExpiresAt ? 'YouTube upload permission connected for this session' : 'YouTube publishing not connected'}
                  </div>
                  {overview.youtubeOAuthConfigured ? (
                    <button className="primary-button" onClick={connectYouTube} disabled={youtubeConnecting}>
                      {youtubeConnecting ? <Loader2 className="spin" size={16} /> : <Youtube size={16} />}
                      {youtubeConnecting ? 'Connecting…' : 'Connect YouTube channel'}
                    </button>
                  ) : (
                    <p className="muted-note">Add your Google OAuth client ID and secret in AppDeploy secrets to enable this connection.</p>
                  )}
                  {youtubeAccessToken && Date.now() < youtubeExpiresAt && (
                    <small className="verified">Temporary upload authorization active. It is held in memory and expires automatically.</small>
                  )}
                </div>
              </div>
              <div className="panel">
                <div className="panel-head">
                  <div>
                    <span className="eyebrow">PUBLISHING SAFEGUARDS</span>
                    <h3>Your approval rules</h3>
                  </div>
                  <ShieldCheck size={20} className="green-text" />
                </div>
                <div className="setting-row">
                  <div>
                    <b>Manual approval</b>
                    <small>
                      Every clip stays in review until you approve it.
                    </small>
                  </div>
                  <span className="toggle on">ON</span>
                </div>
                <div className="setting-row">
                  <div>
                    <b>Automatic publishing</b>
                    <small>
                      Disabled until YouTube OAuth, creator permissions and
                      upload checks are configured.
                    </small>
                  </div>
                  <span className="toggle">OFF</span>
                </div>
                <div className="setting-row">
                  <div>
                    <b>Creator attribution</b>
                    <small>
                      Keep source channel and original video link with each
                      clip.
                    </small>
                  </div>
                  <span className="toggle on">ON</span>
                </div>
              </div>
              <div className="panel setup-panel">
                <h3>What is needed to enable direct uploads?</h3>
                <ol>
                  <li>
                    Create a Google Cloud project and enable YouTube Data API
                    v3.
                  </li>
                  <li>
                    Configure an OAuth consent screen and web application
                    client.
                  </li>
                  <li>
                    Add the deployed app's callback URL to the Google OAuth
                    client.
                  </li>
                  <li>
                    Store the client ID, client secret and API key in encrypted
                    AppDeploy secrets.
                  </li>
                  <li>
                    Connect the same Google account that owns or manages your
                    YouTube channel and grant upload permission.
                  </li>
                </ol>
              </div>
            </>
          )}
          {section === 'Settings' && (
            <>
              <div className="page-heading">
                <div>
                  <span className="eyebrow">WORKSPACE CONFIGURATION</span>
                  <h1>
                    Settings<span>.</span>
                  </h1>
                  <p>Account, integrations and processing safeguards.</p>
                </div>
              </div>
              <div className="panel account-panel">
                <div className="account-avatar">
                  {user.picture ? (
                    <img src={user.picture} alt="" />
                  ) : (
                    <Gamepad2 size={22} />
                  )}
                </div>
                <div>
                  <b>{user.name || 'Google account'}</b>
                  <small>{user.email}</small>
                  <span className="verified">
                    <Check size={13} /> Signed in securely with Google
                  </span>
                </div>
                <button className="secondary-button" onClick={signOut}>
                  <LogOut size={15} /> Sign out
                </button>
              </div>
              <div className="panel">
                <div className="panel-head">
                  <div>
                    <span className="eyebrow">INTEGRATION STATUS</span>
                    <h3>Connected services</h3>
                  </div>
                  <Settings size={18} />
                </div>
                <div className="integration-row">
                  <div className="integration-icon youtube">
                    <Youtube size={19} />
                  </div>
                  <div>
                    <b>YouTube Data API</b>
                    <small>
                      {overview.youtubeConfigured
                        ? 'API key configured'
                        : 'API key not configured'}
                    </small>
                  </div>
                  <span
                    className={
                      'status-chip ' +
                      (overview.youtubeConfigured ? 'approved' : '')
                    }
                  >
                    {overview.youtubeConfigured ? 'READY' : 'SETUP NEEDED'}
                  </span>
                </div>
                <div className="integration-row">
                  <div className="integration-icon">
                    <Sparkles size={19} />
                  </div>
                  <div>
                    <b>AI moment analysis</b>
                    <small>
                      AI title, hook, category and potential scoring
                    </small>
                  </div>
                  <span className="status-chip approved">AVAILABLE</span>
                </div>
                <div className="integration-row">
                  <div className="integration-icon youtube">
                    <Youtube size={19} />
                  </div>
                  <div>
                    <b>YouTube Shorts upload</b>
                    <small>{overview.youtubeOAuthConfigured ? 'OAuth credentials configured; connect your channel in Publishing' : 'Google OAuth client credentials still required'}</small>
                  </div>
                  <span className={'status-chip ' + (overview.youtubeOAuthConfigured ? 'approved' : '')}>{overview.youtubeOAuthConfigured ? 'READY TO CONNECT' : 'SETUP NEEDED'}</span>
                </div>
              </div>
              <div className="panel safety-panel">
                <ShieldCheck size={20} />
                <div>
                  <b>Responsible clipping</b>
                  <p>
                    Public visibility is not permission to reuse content. Only
                    process creator-authorized footage, preserve attribution,
                    and check the rights to gameplay, commentary and music
                    before publishing.
                  </p>
                </div>
              </div>
            </>
          )}
        </div>
      </main>
      {showMoment && (
        <div
          className="modal-backdrop"
          onMouseDown={e => {
            if (e.target === e.currentTarget) setShowMoment(false);
          }}
        >
          <form className="moment-modal" onSubmit={analyzeMoment}>
            <div className="modal-head">
              <div>
                <span className="eyebrow">AI MOMENT ANALYSIS</span>
                <h2>Find the viral angle</h2>
                <p>
                  Describe a moment from footage you have permission to use.
                </p>
              </div>
              <button
                type="button"
                className="icon-button"
                onClick={() => setShowMoment(false)}
              >
                <X size={19} />
              </button>
            </div>
            <label>
              Stream or video title
              <input
                value={moment.sourceTitle}
                onChange={e =>
                  setMoment({ ...moment, sourceTitle: e.target.value })
                }
                placeholder="e.g. First GTA 6 police chase"
                required
              />
            </label>
            <label>
              Source video URL
              <input
                type="url"
                value={moment.sourceUrl}
                onChange={e =>
                  setMoment({ ...moment, sourceUrl: e.target.value })
                }
                placeholder="https://youtube.com/watch?v=…"
                required
              />
            </label>
            <div className="form-two">
              <label>
                Creator / channel
                <input
                  value={moment.creator}
                  onChange={e =>
                    setMoment({ ...moment, creator: e.target.value })
                  }
                  placeholder="Channel name"
                />
              </label>
              <label>
                Moment start
                <input
                  value={moment.startTime}
                  onChange={e =>
                    setMoment({ ...moment, startTime: e.target.value })
                  }
                  placeholder="00:12"
                  required
                />
              </label>
            </div>
            <label>
              Moment end
              <input
                value={moment.endTime}
                onChange={e =>
                  setMoment({ ...moment, endTime: e.target.value })
                }
                placeholder="00:48"
                required
              />
            </label>
            <label>
              What happens in this moment?
              <textarea
                value={moment.notes}
                onChange={e => setMoment({ ...moment, notes: e.target.value })}
                placeholder="Describe the gameplay, reaction, dialogue or unexpected event…"
                rows={4}
                required
              />
            </label>
            <div className="modal-note">
              <ShieldCheck size={15} /> Confirm you own this footage or have
              permission to create and publish clips from it.
            </div>
            <button
              className="primary-button full-button"
              disabled={momentBusy}
            >
              {momentBusy ? (
                <Loader2 className="spin" size={17} />
              ) : (
                <Sparkles size={17} />
              )}{' '}
              Analyze and add to review queue
            </button>
          </form>
        </div>
      )}
    </div>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
  sub,
  tone,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
  sub: string;
  tone: string;
}) {
  return (
    <div className="stat-card">
      <div className={'stat-icon ' + tone}>
        <Icon size={19} />
      </div>
      <span>{label}</span>
      <strong>{value}</strong>
      <small>{sub}</small>
    </div>
  );
}

function GoogleGlyph() {
  return (
    <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">
      <path
        fill="#FFC107"
        d="M43.6 20.5H42V20H24v8h11.3A12 12 0 1 1 24 12a11.8 11.8 0 0 1 7.9 3l5.7-5.7A20 20 0 1 0 44 24c0-1.2-.1-2.3-.4-3.5Z"
      />
      <path
        fill="#FF3D00"
        d="m6.3 14.7 6.6 4.8A12 12 0 0 1 24 12c3 0 5.7 1.1 7.9 3l5.7-5.7A20 20 0 0 0 6.3 14.7Z"
      />
      <path
        fill="#4CAF50"
        d="M24 44a20 20 0 0 0 13.5-5.2l-6.2-5.2A12 12 0 0 1 12.8 29l-6.5 5A20 20 0 0 0 24 44Z"
      />
      <path
        fill="#1976D2"
        d="M43.6 20.5H42V20H24v8h11.3a12 12 0 0 1-4 5.6l6.2 5.2C41.3 35.2 44 29.9 44 24c0-1.2-.1-2.3-.4-3.5Z"
      />
    </svg>
  );
}

export default App;
