import { useEffect, useRef, useState } from 'react';
import { api } from '@appdeploy/client';
import type { FFmpeg } from '@ffmpeg/ffmpeg';
import { Download, FileVideo, Loader2, ShieldCheck, Video, Sparkles } from 'lucide-react';

type Caption = { start: number; end: number; text: string };
type MomentSuggestion = {
  startSeconds: number;
  endSeconds: number;
  label: string;
  reason: string;
  score: number;
  hookStrength: number;
  humour: number;
  surprise: number;
  emotion: number;
  clarity: number;
  replayPotential: number;
};

function parseTime(value: string) {
  const parts = value.split(':').map(Number);
  if (parts.length === 3) return (parts[0] || 0) * 3600 + (parts[1] || 0) * 60 + (parts[2] || 0);
  if (parts.length === 2) return (parts[0] || 0) * 60 + (parts[1] || 0);
  return Number(value) || 0;
}

function srtStamp(seconds: number) {
  const ms = Math.max(0, Math.round(seconds * 1000));
  const hours = Math.floor(ms / 3600000);
  const minutes = Math.floor((ms % 3600000) / 60000);
  const secs = Math.floor((ms % 60000) / 1000);
  const millis = ms % 1000;
  return [hours, minutes, secs].map(value => String(value).padStart(2, '0')).join(':') + ',' + String(millis).padStart(3, '0');
}

function toSrt(captions: Caption[]) {
  return captions
    .filter(line => line.end > line.start && line.text.trim())
    .map((line, index) => (index + 1) + '\n' + srtStamp(line.start) + ' --> ' + srtStamp(line.end) + '\n' + line.text.trim())
    .join('\n\n');
}

function clock(seconds: number) {
  const whole = Math.max(0, Math.floor(seconds));
  return Math.floor(whole / 60).toString().padStart(2, '0') + ':' + (whole % 60).toString().padStart(2, '0');
}

export default function AutoClipper({
  sourceTitle,
  initialStart,
  initialEnd,
  captions,
  initialTranscript,
}: {
  sourceTitle: string;
  initialStart: string;
  initialEnd: string;
  captions: Caption[];
  initialTranscript: string;
}) {
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const [renderedUrl, setRenderedUrl] = useState('');
  const [duration, setDuration] = useState(0);
  const [start, setStart] = useState(parseTime(initialStart));
  const [end, setEnd] = useState(parseTime(initialEnd) || 45);
  const [rightsConfirmed, setRightsConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [engineReady, setEngineReady] = useState(false);
  const [message, setMessage] = useState('');
  const [transcript, setTranscript] = useState(initialTranscript || '');
  const [suggestions, setSuggestions] = useState<MomentSuggestion[]>([]);
  const [suggesting, setSuggesting] = useState(false);
  const [selectedMoment, setSelectedMoment] = useState<MomentSuggestion | null>(null);
  const [commentary, setCommentary] = useState<{
    openingHook: string;
    voiceover: string;
    onScreenBeats: string[];
    viewerQuestion: string;
    alternateHook: string;
    originalityNote: string;
  } | null>(null);
  const [commentaryLoading, setCommentaryLoading] = useState(false);
  const ffmpegRef = useRef<FFmpeg | null>(null);

  useEffect(() => {
    return () => {
      if (ffmpegRef.current) ffmpegRef.current.terminate();
    };
  }, []);

  useEffect(() => {
    if (!previewUrl) return;
    return () => URL.revokeObjectURL(previewUrl);
  }, [previewUrl]);

  useEffect(() => {
    if (!renderedUrl) return;
    return () => URL.revokeObjectURL(renderedUrl);
  }, [renderedUrl]);

  function chooseFile(nextFile?: File) {
    setMessage('');
    setRenderedUrl('');
    setSuggestions([]);
    setDuration(0);
    if (!nextFile) {
      setFile(null);
      setPreviewUrl('');
      return;
    }
    if (nextFile.size > 250 * 1024 * 1024) {
      setFile(null);
      setPreviewUrl('');
      setMessage('This file is larger than the 250 MB browser-processing limit. Choose a shorter or smaller source file.');
      return;
    }
    setFile(nextFile);
    setPreviewUrl(URL.createObjectURL(nextFile));
    setEnd(parseTime(initialEnd) || 45);
  }

  async function findMoments() {
    if (!transcript.trim() || duration <= 0) return;
    if (!/\b(?:\d{1,2}:)?\d{1,2}:\d{2}\b/.test(transcript)) {
      setMessage('Add timestamps to the transcript (for example, 00:12 or 01:05) so AI can locate moments accurately.');
      return;
    }
    setSuggesting(true);
    setMessage('');
    setSuggestions([]);
    try {
      const { data } = await api.post('/api/shorts/suggest-moments', {
        transcript: transcript.trim(),
        durationSeconds: duration,
        sourceTitle,
      });
      setSuggestions(data.moments || []);
      setSelectedMoment(null);
      setCommentary(null);
      if (!(data.moments || []).length) {
        setMessage('No reliable moments were found. Add clearer timestamped dialogue or action notes and try again.');
      }
    } catch (e) {
      setMessage(e instanceof Error ? e.message : 'AI moment detection failed. Please retry.');
    } finally {
      setSuggesting(false);
    }
  }

  function chooseMoment(moment: MomentSuggestion) {
    setSelectedMoment(moment);
    setCommentary(null);
    setStart(moment.startSeconds);
    setEnd(moment.endSeconds);
    setRenderedUrl('');
    setMessage('Selected: ' + moment.label + '. Review the range, then generate original commentary if you want it.');
  }

  async function generateCommentary() {
    if (!selectedMoment || !transcript.trim()) return;
    setCommentaryLoading(true);
    setMessage('');
    try {
      const { data } = await api.post('/api/shorts/commentary', {
        sourceTitle,
        transcript: transcript.trim(),
        momentLabel: selectedMoment.label,
        reason: selectedMoment.reason,
        startSeconds: selectedMoment.startSeconds,
        endSeconds: selectedMoment.endSeconds,
      });
      setCommentary(data.commentary);
    } catch (e) {
      setMessage(e instanceof Error ? e.message : 'Could not generate original commentary. Please retry.');
    } finally {
      setCommentaryLoading(false);
    }
  }

  const clipLength = end - start;
  const canRender = Boolean(file && rightsConfirmed && duration > 0 && start >= 0 && end > start && end <= duration && clipLength <= 60);

  async function renderClip() {
    if (!file || !canRender) return;
    setBusy(true);
    setProgress(0);
    setMessage('Loading the local video engine. The first load is about 31 MB.');
    setRenderedUrl('');
    try {
      const [{ FFmpeg }, { toBlobURL }] = await Promise.all([
        import('@ffmpeg/ffmpeg'),
        import('@ffmpeg/util'),
      ]);
      let ffmpeg = ffmpegRef.current;
      if (!ffmpeg) {
        ffmpeg = new FFmpeg();
        ffmpeg.on('progress', ({ progress: ratio }) => {
          setProgress(Math.max(0, Math.min(100, Math.round(ratio * 100))));
        });
        ffmpegRef.current = ffmpeg;
      }
      if (!engineReady) {
        const baseURL = 'https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.10/dist/esm';
        await ffmpeg.load({
          coreURL: await toBlobURL(baseURL + '/ffmpeg-core.js', 'text/javascript'),
          wasmURL: await toBlobURL(baseURL + '/ffmpeg-core.wasm', 'application/wasm'),
        });
        setEngineReady(true);
      }

      setMessage('Preparing the selected source locally on this device…');
      await ffmpeg.writeFile('clipforge-source.bin', new Uint8Array(await file.arrayBuffer()));
      const validCaptions = captions.filter(line => line.end > line.start && line.text.trim());
      const filters = [
        'scale=720:1280:force_original_aspect_ratio=increase',
        'crop=720:1280',
        'setsar=1',
      ];
      if (validCaptions.length) {
        await ffmpeg.writeFile('clipforge-captions.srt', new TextEncoder().encode(toSrt(validCaptions)));
        filters.push("subtitles=clipforge-captions.srt:force_style='FontName=Arial,FontSize=26,Outline=2,Shadow=1,Alignment=2,MarginV=110'");
      }

      setMessage('Rendering a vertical 9:16 MP4 with H.264 video and AAC audio…');
      const exitCode = await ffmpeg.exec([
        '-ss', String(start),
        '-i', 'clipforge-source.bin',
        '-t', String(clipLength),
        '-vf', filters.join(','),
        '-map', '0:v:0',
        '-map', '0:a?',
        '-c:v', 'libx264',
        '-preset', 'ultrafast',
        '-crf', '27',
        '-pix_fmt', 'yuv420p',
        '-c:a', 'aac',
        '-b:a', '128k',
        '-movflags', '+faststart',
        '-y', 'clipforge-short.mp4',
      ]);
      if (exitCode !== 0) throw new Error('The video engine returned exit code ' + exitCode + '.');
      const output = await ffmpeg.readFile('clipforge-short.mp4');
      if (typeof output === 'string') throw new Error('The video engine returned an invalid MP4 file.');
      const blob = new Blob([output as BlobPart], { type: 'video/mp4' });
      setRenderedUrl(URL.createObjectURL(blob));
      setProgress(100);
      setMessage('Your MP4 is ready. Preview it and download it for review before publishing.');
      await ffmpeg.deleteFile('clipforge-source.bin').catch(() => undefined);
      await ffmpeg.deleteFile('clipforge-short.mp4').catch(() => undefined);
      if (validCaptions.length) await ffmpeg.deleteFile('clipforge-captions.srt').catch(() => undefined);
    } catch (e) {
      setMessage(e instanceof Error ? 'Render failed: ' + e.message : 'Render failed. Try a smaller MP4 source file.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <div className="page-heading">
        <div>
          <span className="eyebrow">LOCAL VIDEO PROCESSING</span>
          <h1>Auto Clipper<span>.</span></h1>
          <p>Find promising moments from a timestamped transcript, then render a real vertical MP4 from authorised footage.</p>
        </div>
        <span className="status-chip">9:16 · MP4</span>
      </div>
      <div className="panel discovery-callout">
        <div className="callout-icon"><ShieldCheck size={21} /></div>
        <div>
          <b>Your footage stays on this device</b>
          <p>ClipForge processes the selected file in your browser. It is not uploaded to ClipForge. Use only footage you own or have permission to edit and publish. Public YouTube search results do not grant reuse rights.</p>
        </div>
      </div>
      <section className="panel clipper-panel moment-finder-panel">
        <span className="eyebrow">AI MOMENT FINDER</span>
        <h3>Find the strongest moments</h3>
        <p className="topic-hint">Paste a timestamped transcript or notes. AI uses those timestamps to suggest short highlights; it does not watch or download public YouTube videos.</p>
        <label>Timestamped transcript or notes
          <textarea
            rows={5}
            value={transcript}
            onChange={event => setTranscript(event.target.value)}
            placeholder={'[00:12] The player spots the police ambush…\n[00:28] The car launches over the bridge…\n[00:41] The streamer bursts out laughing…'}
          />
        </label>
        <button className="primary-button" type="button" disabled={suggesting || !transcript.trim() || duration <= 0} onClick={findMoments}>
          {suggesting ? <Loader2 className="spin" size={16} /> : <Sparkles size={16} />}
          {suggesting ? 'Finding highlights…' : 'Find best moments with AI'}
        </button>
        {duration <= 0 && <p className="topic-hint">Choose your authorised video file below first so suggestions can be checked against its duration.</p>}
        {suggestions.length > 0 && (
          <div className="moment-suggestions">
            {suggestions.map((moment, index) => (
              <button className={'moment-suggestion ' + (start === moment.startSeconds && end === moment.endSeconds ? 'selected' : '')} key={index} type="button" onClick={() => chooseMoment(moment)}>
                <span className="moment-score">{moment.score}/100</span>
                <b>{moment.label}</b>
                <small>{clock(moment.startSeconds)}–{clock(moment.endSeconds)} · {moment.reason}</small>
                <small>Hook {moment.hookStrength} · Humour {moment.humour} · Surprise {moment.surprise} · Emotion {moment.emotion} · Replay {moment.replayPotential}</small>
                <span className="moment-select">Use this moment</span>
              </button>
            ))}
          </div>
        )}
        {selectedMoment && (
          <div className="commentary-engine">
            <div className="setting-row">
              <div><b>Selected: {selectedMoment.label}</b><small>Smart Viral Score: {selectedMoment.score}/100</small></div>
              <span className="status-chip">RANKED</span>
            </div>
            <button className="primary-button" type="button" disabled={commentaryLoading} onClick={generateCommentary}>
              {commentaryLoading ? <Loader2 className="spin" size={16} /> : <Sparkles size={16} />}
              {commentaryLoading ? 'Writing original commentary…' : 'Generate original AI commentary'}
            </button>
            {commentary && (
              <div className="commentary-result">
                <div><b>Opening hook</b><p>{commentary.openingHook}</p></div>
                <div><b>Original voiceover</b><p>{commentary.voiceover}</p></div>
                <div><b>On-screen beats</b><ul>{commentary.onScreenBeats.map((beat, index) => <li key={index}>{beat}</li>)}</ul></div>
                <div><b>Viewer question</b><p>{commentary.viewerQuestion}</p></div>
                <div><b>Alternate hook</b><p>{commentary.alternateHook}</p></div>
                <small>{commentary.originalityNote}</small>
              </div>
            )}
          </div>
        )}
      </section>
      <div className="clipper-grid">
        <section className="panel clipper-panel">
          <span className="eyebrow">STEP 01 · SOURCE FOOTAGE</span>
          <h3>Choose a video file</h3>
          {sourceTitle && <p className="clipper-source-title">AI Studio source: {sourceTitle}</p>}
          <label className="clipper-file-label">
            <FileVideo size={18} />
            Select video from this device
            <input type="file" accept="video/*,.mkv,.mov,.mp4,.webm" onChange={event => chooseFile(event.currentTarget.files?.[0])} />
          </label>
          {file && <p className="topic-hint">{file.name} · {(file.size / (1024 * 1024)).toFixed(1)} MB</p>}
          {previewUrl && (
            <video
              className="clipper-video"
              src={previewUrl}
              controls
              playsInline
              onLoadedMetadata={event => {
                const seconds = event.currentTarget.duration;
                setDuration(seconds);
                setEnd(current => Math.min(current || 45, seconds));
              }}
            />
          )}
          {duration > 0 && <p className="topic-hint">Source duration: {duration.toFixed(1)} seconds</p>}
        </section>
        <section className="panel clipper-panel">
          <span className="eyebrow">STEP 02 · CLIP SETTINGS</span>
          <h3>Choose the moment</h3>
          <div className="clipper-time-grid">
            <label>Start time (seconds)
              <input type="number" min="0" max={duration || undefined} step="0.1" value={start} onChange={event => setStart(Number(event.target.value))} />
            </label>
            <label>End time (seconds)
              <input type="number" min="0" max={duration || undefined} step="0.1" value={end} onChange={event => setEnd(Number(event.target.value))} />
            </label>
          </div>
          <div className="setting-row">
            <div><b>Clip duration</b><small>{Math.max(0, clipLength).toFixed(1)} seconds · maximum 60 seconds</small></div>
            <span className="status-chip">720 × 1280</span>
          </div>
          <div className="clipper-caption-state">
            <b>{captions.length ? captions.length + ' timed caption lines ready' : 'No timed captions attached'}</b>
            <small>{captions.length ? 'AI Studio captions will be burned into the MP4.' : 'Render will contain the original audio and video without burned-in captions. Generate a plan in AI Studio first to add captions.'}</small>
          </div>
          <label className="clipper-rights">
            <input type="checkbox" checked={rightsConfirmed} onChange={event => setRightsConfirmed(event.target.checked)} />
            I own this footage or have permission to create and publish clips from it.
          </label>
          <button className="primary-button full-button" type="button" disabled={!canRender || busy} onClick={renderClip}>
            {busy ? <Loader2 className="spin" size={16} /> : <Video size={16} />}
            {busy ? 'Rendering MP4…' : 'Render vertical MP4'}
          </button>
          {busy && <div className="clipper-progress"><div style={{ width: progress + '%' }} /><span>{progress}%</span></div>}
          {message && <p className="clipper-message">{message}</p>}
          <p className="topic-hint">The first render downloads a roughly 31 MB FFmpeg engine. Keep clips under 60 seconds; browser memory is limited, especially on phones.</p>
        </section>
      </div>
      {renderedUrl && (
        <section className="panel clipper-output">
          <div className="panel-head">
            <div><span className="eyebrow">STEP 03 · FINISHED EXPORT</span><h3>MP4 ready for review</h3></div>
            <span className="status-chip">REVIEW FIRST</span>
          </div>
          <video className="clipper-video output-video" src={renderedUrl} controls playsInline />
          <a className="primary-button" href={renderedUrl} download="clipforge-short.mp4"><Download size={15} /> Download MP4</a>
        </section>
      )}
    </>
  );
}
