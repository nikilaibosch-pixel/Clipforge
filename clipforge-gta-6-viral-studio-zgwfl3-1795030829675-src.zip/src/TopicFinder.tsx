import { useState } from 'react';
import { api } from '@appdeploy/client';
import { ExternalLink, Loader2, Search, Sparkles, TrendingUp } from 'lucide-react';

export type TopicVideo = {
  videoId: string;
  title: string;
  channelTitle: string;
  thumbnail: string;
  url: string;
  publishedAt: string;
  duration: string;
  viewCount: number;
  likeCount: number;
  commentCount: number;
  engagementRate: number;
  relevanceScore: number;
  opportunityScore: number;
  liveBroadcastContent: string;
};

function compact(value: number) {
  return new Intl.NumberFormat('en-ZA', {
    notation: 'compact',
    maximumFractionDigits: 1,
  }).format(value || 0);
}

export default function TopicFinder({ onUse }: { onUse: (item: TopicVideo) => void }) {
  const [topic, setTopic] = useState('');
  const [creator, setCreator] = useState('');
  const [days, setDays] = useState('0');
  const [minViews, setMinViews] = useState('0');
  const [items, setItems] = useState<TopicVideo[]>([]);
  const [busy, setBusy] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [searchedTopic, setSearchedTopic] = useState('');

  async function searchTopic(event: React.FormEvent) {
    event.preventDefault();
    if (topic.trim().length < 2) {
      setErrorMessage('Enter at least two characters for your topic.');
      return;
    }
    setBusy(true);
    setErrorMessage('');
    try {
      const { data } = await api.post('/api/youtube/topic-search', {
        topic: topic.trim(),
        creator: creator.trim(),
        days: Number(days),
        minViews: Number(minViews || 0),
      });
      setItems(data.items || []);
      setSearchedTopic(topic.trim());
    } catch (e) {
      setErrorMessage(e instanceof Error ? e.message : 'YouTube topic search failed. Please retry.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <div className="page-heading">
        <div>
          <span className="eyebrow">YOUTUBE TOPIC INTELLIGENCE</span>
          <h1>Topic Finder<span>.</span></h1>
          <p>Search by subject, then compare public videos by views, relevance and engagement.</p>
        </div>
        <span className="status-chip">PUBLIC SEARCH</span>
      </div>
      <form className="panel topic-search-panel" onSubmit={searchTopic}>
        <div className="topic-search-main">
          <label>
            Search topic
            <input
              value={topic}
              onChange={event => setTopic(event.target.value)}
              placeholder="Try GPT, AI news, GTA 6, funny gaming moments…"
              minLength={2}
              required
            />
          </label>
          <button className="primary-button" disabled={busy || topic.trim().length < 2}>
            {busy ? <Loader2 className="spin" size={16} /> : <Search size={16} />}
            {busy ? 'Searching YouTube…' : 'Find popular videos'}
          </button>
        </div>
        <div className="topic-filter-grid">
          <label>
            Creator filter <small>Optional</small>
            <input value={creator} onChange={event => setCreator(event.target.value)} placeholder="Channel name" />
          </label>
          <label>
            Date range
            <select value={days} onChange={event => setDays(event.target.value)}>
              <option value="0">Any time</option>
              <option value="7">Past 7 days</option>
              <option value="30">Past 30 days</option>
              <option value="90">Past 3 months</option>
              <option value="365">Past year</option>
            </select>
          </label>
          <label>
            Minimum views
            <input type="number" min="0" value={minViews} onChange={event => setMinViews(event.target.value)} />
          </label>
        </div>
        <p className="topic-hint">No video links needed. YouTube's public search returns a limited result set; date filters can reduce the number of matches.</p>
      </form>
      {errorMessage && <div className="alert error">{errorMessage}</div>}
      {items.length > 0 && (
        <div className="panel topic-results-panel">
          <div className="panel-head">
            <div>
              <span className="eyebrow">RESULTS · SORTED BY VIEWS</span>
              <h3>{items.length} videos for “{searchedTopic}”</h3>
            </div>
            <span className="count-pill">{items.length} found</span>
          </div>
          <div className="topic-results">
            {items.map(item => (
              <article className="topic-result" key={item.videoId}>
                {item.thumbnail ? <img src={item.thumbnail} alt="" /> : <div className="topic-thumb-fallback"><Search size={22} /></div>}
                <div className="topic-result-copy">
                  <b>{item.title}</b>
                  <span>{item.channelTitle}</span>
                  <div className="topic-result-meta">
                    <span>{compact(item.viewCount)} views</span>
                    <span>{item.publishedAt ? new Date(item.publishedAt).toLocaleDateString() : 'Date unavailable'}</span>
                    {item.duration && <span>{item.duration}</span>}
                    {item.liveBroadcastContent === 'live' && <span className="topic-live">LIVE</span>}
                  </div>
                  <div className="topic-score-row">
                    <span><TrendingUp size={13} /> {item.opportunityScore}/100 opportunity</span>
                    <span>{item.engagementRate.toFixed(2)}% engagement</span>
                    <span>{item.relevanceScore}% relevance</span>
                  </div>
                </div>
                <div className="topic-result-actions">
                  <a className="secondary-button" href={item.url} target="_blank" rel="noreferrer">
                    Open <ExternalLink size={13} />
                  </a>
                  <button className="primary-button" type="button" onClick={() => onUse(item)}>
                    <Sparkles size={14} /> Use in AI Studio
                  </button>
                </div>
              </article>
            ))}
          </div>
          <p className="topic-hint">Views and engagement are public YouTube statistics, not a prediction of future performance. Search results do not grant permission to download or reuse footage.</p>
        </div>
      )}
      {!busy && searchedTopic && items.length === 0 && !errorMessage && (
        <div className="panel empty-state">
          <div className="empty-icon"><Search size={24} /></div>
          <h3>No matching videos found</h3>
          <p>Try a broader topic, remove the creator filter or expand the date range.</p>
        </div>
      )}
      {!searchedTopic && (
        <div className="panel empty-state">
          <div className="empty-icon"><TrendingUp size={24} /></div>
          <h3>Find what is already attracting attention</h3>
          <p>Enter any topic to find public videos with strong view counts. Select a result to carry its title and creator into AI Studio.</p>
        </div>
      )}
    </>
  );
}
