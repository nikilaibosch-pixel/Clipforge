import {
  ai,
  db,
  json,
  error,
  requireAuth,
  router,
  secrets,
} from '@appdeploy/sdk';

type MomentInput = {
  sourceTitle?: string;
  sourceUrl?: string;
  creator?: string;
  startTime?: string;
  endTime?: string;
  notes?: string;
};
type SavedClip = {
  ownerId: string;
  title: string;
  category: string;
  score: number;
  hook: string;
  description: string;
  hashtags: string[];
  startTime: string;
  endTime: string;
  sourceTitle: string;
  sourceUrl: string;
  creator: string;
  status: string;
  createdAt: string;
};
type SavedStream = {
  ownerId: string;
  title: string;
  url: string;
  sourceType: string;
  createdAt: string;
};
type OAuthState = SavedStream & { expiresAt: number };
type AutoDiscovery = {
  ownerId: string;
  videoId: string;
  title: string;
  channelTitle: string;
  thumbnail: string;
  url: string;
  sourceType: 'live' | 'popular';
  viewCount: number;
  likeCount: number;
  publishedAt: string;
  duration: string;
  discoveredAt: string;
};

const APP_URL = 'https://clipforge-gta-6-viral-studio-zgwfl3.v2.appdeploy.ai';
const YOUTUBE_CALLBACK_URL = APP_URL + '/';
const READY_TO_CLIP_FOLDER_ID = '1WPTmMUNlFMXOHOzQ2AfGdHUjYbwXA_t-';

function redirectToApp(values: Record<string, string>) {
  const target = new URL(APP_URL + '/');
  target.hash = new URLSearchParams(values).toString();
  return {
    statusCode: 302,
    headers: {
      Location: target.toString(),
      'Cache-Control': 'no-store, max-age=0',
      'Referrer-Policy': 'no-referrer',
    },
    body: '',
  };
}

async function collectPublicGta6Videos(creator = '') {
  const names = await secrets.listSecretNames();
  if (!names.includes('YOUTUBE_API_KEY')) return { configured: false, items: [] as AutoDiscovery[] };
  const key = await secrets.readSecret('YOUTUBE_API_KEY');
  const query = ['GTA 6', creator].filter(Boolean).join(' ');
  const search = async (mode: 'live' | 'popular') => {
    const url = new URL('https://www.googleapis.com/youtube/v3/search');
    url.searchParams.set('part', 'snippet');
    url.searchParams.set('type', 'video');
    url.searchParams.set('q', query);
    url.searchParams.set('maxResults', '25');
    url.searchParams.set('key', key);
    if (mode === 'live') url.searchParams.set('eventType', 'live');
    else url.searchParams.set('order', 'viewCount');
    const response = await fetch(url.toString());
    if (!response.ok) throw new Error('YouTube discovery request failed (' + response.status + ').');
    const payload = await response.json() as {
      items?: Array<{
        id?: { videoId?: string };
        snippet?: {
          title?: string;
          channelTitle?: string;
          publishedAt?: string;
          thumbnails?: { medium?: { url?: string } };
        };
      }>;
    };
    return (payload.items || []).filter(item => item.id?.videoId).map(item => ({
      videoId: item.id!.videoId!,
      title: item.snippet?.title || 'Untitled GTA 6 video',
      channelTitle: item.snippet?.channelTitle || 'Unknown creator',
      thumbnail: item.snippet?.thumbnails?.medium?.url || '',
      publishedAt: item.snippet?.publishedAt || '',
      sourceType: mode,
    }));
  };

  const found = [...await search('live'), ...await search('popular')];
  const ids = [...new Set(found.map(item => item.videoId))];
  if (!ids.length) return { configured: true, items: [] as AutoDiscovery[] };

  const detailsUrl = new URL('https://www.googleapis.com/youtube/v3/videos');
  detailsUrl.searchParams.set('part', 'statistics,contentDetails');
  detailsUrl.searchParams.set('id', ids.join(','));
  detailsUrl.searchParams.set('key', key);
  const detailsResponse = await fetch(detailsUrl.toString());
  if (!detailsResponse.ok) throw new Error('YouTube could not return popularity statistics (' + detailsResponse.status + ').');
  const details = await detailsResponse.json() as {
    items?: Array<{
      id?: string;
      statistics?: { viewCount?: string; likeCount?: string };
      contentDetails?: { duration?: string };
    }>;
  };
  const stats = new Map((details.items || []).map(item => [item.id || '', item]));
  const foundById = new Map(found.map(item => [item.videoId, item]));
  const unique: AutoDiscovery[] = ids.map(videoId => {
    const item = foundById.get(videoId)!;
    const detail = stats.get(videoId);
    return {
      ownerId: 'public-discovery',
      videoId,
      title: item.title,
      channelTitle: item.channelTitle,
      thumbnail: item.thumbnail,
      url: 'https://www.youtube.com/watch?v=' + videoId,
      sourceType: item.sourceType,
      viewCount: Number(detail?.statistics?.viewCount || 0),
      likeCount: Number(detail?.statistics?.likeCount || 0),
      publishedAt: item.publishedAt,
      duration: detail?.contentDetails?.duration || '',
      discoveredAt: new Date().toISOString(),
    };
  }).sort((a, b) => b.viewCount - a.viewCount);

  const existing = await db.list<AutoDiscovery & { id?: string }>('clipforge_discoveries', { limit: 500 });
  const byVideoId = new Map(existing.items.map(item => [item.videoId, item]));
  const updates = unique
    .map(item => {
      const saved = byVideoId.get(item.videoId);
      return saved?.id ? { id: saved.id, record: item } : null;
    })
    .filter((item): item is { id: string; record: AutoDiscovery } => Boolean(item));
  if (updates.length) await db.tx.update('clipforge_discoveries', updates, { patch: true });
  const fresh = unique.filter(item => !byVideoId.has(item.videoId));
  for (let i = 0; i < fresh.length; i += 100) {
    await db.add('clipforge_discoveries', fresh.slice(i, i + 100));
  }
  return { configured: true, items: unique };
}

export const automaticGta6Discovery = async (_event: { type: 'cron'; name: string; invocationId: string; scheduledTime: string; invokedTime: string }) => {
  try {
    await collectPublicGta6Videos();
  } catch (e) {
    console.error('Automatic GTA 6 discovery failed:', e);
  }
  return { statusCode: 200 };
};

const routes = {
  'GET /api/health': [async () => json({ ok: true, service: 'ClipForge' })],
  'GET /api/overview': [
    requireAuth(),
    async ctx => {
      const ownerId = ctx.user!.userId;
      const [streamsPage, clipsPage, secretNames] = await Promise.all([
        db.list<SavedStream>('clipforge_streams', { limit: 100 }),
        db.list<SavedClip>('clipforge_clips', { limit: 100 }),
        secrets.listSecretNames(),
      ]);
      const streams = streamsPage.items.filter(
        item => item.ownerId === ownerId && item.sourceType !== 'youtube-oauth-state'
      );
      const clips = clipsPage.items.filter(item => item.ownerId === ownerId);
      return json({
        streams,
        clips,
        youtubeConfigured: secretNames.includes('YOUTUBE_API_KEY'),
        youtubeOAuthConfigured:
          secretNames.includes('GOOGLE_OAUTH_CLIENT_ID') &&
          secretNames.includes('GOOGLE_OAUTH_CLIENT_SECRET'),
      });
    },
  ],
  'GET /api/youtube/discoveries': [
    requireAuth(),
    async () => {
      const page = await db.list<AutoDiscovery>('clipforge_discoveries', { limit: 200 });
      const items = page.items.slice().sort((a, b) => (b.viewCount || 0) - (a.viewCount || 0) || b.discoveredAt.localeCompare(a.discoveredAt));
      return json({ configured: (await secrets.listSecretNames()).includes('YOUTUBE_API_KEY'), items });
    },
  ],
  'POST /api/youtube/discoveries/refresh': [
    requireAuth(),
    async ctx => {
      const body = (ctx.body || {}) as { creator?: string };
      try {
        const result = await collectPublicGta6Videos(String(body.creator || '').trim().slice(0, 100));
        return json(result);
      } catch (e) {
        return error(e instanceof Error ? e.message : 'Automatic discovery failed.', 502);
      }
    },
  ],
  'POST /api/youtube/topic-search': [
    requireAuth(),
    async ctx => {
      const body = (ctx.body || {}) as {
        topic?: string;
        creator?: string;
        days?: number;
        minViews?: number;
      };
      const topic = String(body.topic || '').trim().slice(0, 100);
      const creator = String(body.creator || '').trim().slice(0, 100);
      const days = [7, 30, 90, 365].includes(Number(body.days)) ? Number(body.days) : 0;
      const minViews = Math.max(0, Number(body.minViews) || 0);
      if (topic.length < 2) return error('Enter at least two characters for your topic.', 400);

      const names = await secrets.listSecretNames();
      if (!names.includes('YOUTUBE_API_KEY'))
        return error('Add YOUTUBE_API_KEY in AppDeploy secrets to search public YouTube videos.', 409);

      try {
        const key = await secrets.readSecret('YOUTUBE_API_KEY');
        const searchUrl = new URL('https://www.googleapis.com/youtube/v3/search');
        searchUrl.searchParams.set('part', 'snippet');
        searchUrl.searchParams.set('type', 'video');
        searchUrl.searchParams.set('order', 'viewCount');
        searchUrl.searchParams.set('maxResults', '25');
        searchUrl.searchParams.set('q', [topic, creator].filter(Boolean).join(' '));
        searchUrl.searchParams.set('key', key);
        if (days > 0) {
          searchUrl.searchParams.set(
            'publishedAfter',
            new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString()
          );
        }

        const searchResponse = await fetch(searchUrl.toString());
        const searchData = await searchResponse.json() as {
          error?: { message?: string; errors?: Array<{ reason?: string }> };
          items?: Array<{
            id?: { videoId?: string };
            snippet?: {
              title?: string;
              description?: string;
              channelTitle?: string;
              thumbnails?: { medium?: { url?: string }; high?: { url?: string } };
              publishedAt?: string;
              liveBroadcastContent?: string;
            };
          }>;
        };
        if (!searchResponse.ok) {
          const reason = searchData.error?.errors?.[0]?.reason || '';
          return error(
            reason === 'quotaExceeded'
              ? 'YouTube API quota is exhausted. Try again after its quota resets.'
              : 'YouTube topic search failed. Check the API key and YouTube Data API v3 settings.',
            reason === 'quotaExceeded' ? 429 : 502
          );
        }

        const ids = (searchData.items || [])
          .map(item => item.id?.videoId)
          .filter((id): id is string => Boolean(id));
        if (!ids.length) return json({ configured: true, topic, items: [] });

        const videosUrl = new URL('https://www.googleapis.com/youtube/v3/videos');
        videosUrl.searchParams.set('part', 'snippet,statistics,contentDetails');
        videosUrl.searchParams.set('id', ids.join(','));
        videosUrl.searchParams.set('key', key);
        const videosResponse = await fetch(videosUrl.toString());
        const videosData = await videosResponse.json() as {
          error?: { message?: string };
          items?: Array<{
            id?: string;
            snippet?: {
              title?: string;
              description?: string;
              channelTitle?: string;
              thumbnails?: { medium?: { url?: string }; high?: { url?: string } };
              publishedAt?: string;
              liveBroadcastContent?: string;
            };
            statistics?: { viewCount?: string; likeCount?: string; commentCount?: string };
            contentDetails?: { duration?: string };
          }>;
        };
        if (!videosResponse.ok)
          return error('YouTube could not return video statistics. Please retry.', 502);

        const terms = topic.toLowerCase().split(/[^a-z0-9]+/).filter(term => term.length > 1);
        const candidates = (videosData.items || []).map(item => {
          const title = item.snippet?.title || 'Untitled video';
          const description = item.snippet?.description || '';
          const channelTitle = item.snippet?.channelTitle || 'Unknown creator';
          const viewCount = Number(item.statistics?.viewCount || 0);
          const likeCount = Number(item.statistics?.likeCount || 0);
          const commentCount = Number(item.statistics?.commentCount || 0);
          const haystack = (title + ' ' + description).toLowerCase();
          const relevanceScore = terms.length
            ? Math.round(terms.filter(term => haystack.includes(term)).length / terms.length * 100)
            : 0;
          const engagementRate = viewCount > 0
            ? (likeCount + commentCount) / viewCount * 100
            : 0;
          return {
            videoId: item.id || '',
            title,
            channelTitle,
            thumbnail: item.snippet?.thumbnails?.high?.url || item.snippet?.thumbnails?.medium?.url || '',
            url: 'https://www.youtube.com/watch?v=' + (item.id || ''),
            publishedAt: item.snippet?.publishedAt || '',
            duration: item.contentDetails?.duration || '',
            viewCount,
            likeCount,
            commentCount,
            engagementRate,
            relevanceScore,
            opportunityScore: 0,
            liveBroadcastContent: item.snippet?.liveBroadcastContent || 'none',
          };
        }).filter(item =>
          item.videoId &&
          (!creator || item.channelTitle.toLowerCase().includes(creator.toLowerCase())) &&
          item.viewCount >= minViews
        );

        const maxViews = Math.max(1, ...candidates.map(item => item.viewCount));
        for (const item of candidates) {
          const viewScore = Math.round(Math.log10(item.viewCount + 1) / Math.log10(maxViews + 1) * 100);
          const engagementScore = Math.min(100, item.engagementRate * 10);
          item.opportunityScore = Math.round(viewScore * 0.7 + item.relevanceScore * 0.2 + engagementScore * 0.1);
        }
        candidates.sort((a, b) => b.viewCount - a.viewCount);
        return json({ configured: true, topic, count: candidates.length, items: candidates });
      } catch (e) {
        console.error('YouTube topic search failed:', e);
        return error('YouTube topic search could not be completed. Please retry.', 502);
      }
    },
  ],
  'GET /api/youtube/live': [
    requireAuth(),
    async () => {
      const names = await secrets.listSecretNames();
      if (!names.includes('YOUTUBE_API_KEY'))
        return json({ configured: false, items: [] });
      const key = await secrets.readSecret('YOUTUBE_API_KEY');
      const searchUrl = new URL('https://www.googleapis.com/youtube/v3/search');
      searchUrl.searchParams.set('part', 'snippet');
      searchUrl.searchParams.set('type', 'video');
      searchUrl.searchParams.set('eventType', 'live');
      searchUrl.searchParams.set('q', 'GTA 6');
      searchUrl.searchParams.set('maxResults', '25');
      searchUrl.searchParams.set('key', key);
      const response = await fetch(searchUrl.toString());
      if (!response.ok)
        return error(
          'YouTube live search failed. Check the API key and YouTube Data API v3 settings.',
          502
        );
      const payload = (await response.json()) as {
        items?: Array<{
          id?: { videoId?: string };
          snippet?: {
            title?: string;
            channelTitle?: string;
            thumbnails?: { medium?: { url?: string } };
            publishedAt?: string;
          };
        }>;
      };
      const items = (payload.items || [])
        .filter(item => item.id?.videoId)
        .map(item => ({
          videoId: item.id!.videoId!,
          title: item.snippet?.title || 'Untitled live stream',
          channelTitle: item.snippet?.channelTitle || 'Unknown channel',
          thumbnail: item.snippet?.thumbnails?.medium?.url || '',
          publishedAt: item.snippet?.publishedAt,
          url: 'https://www.youtube.com/watch?v=' + item.id!.videoId,
        }));
      return json({ configured: true, items });
    },
  ],
  'GET /api/youtube/oauth/start': [
    requireAuth(),
    async ctx => {
      const names = await secrets.listSecretNames();
      if (!names.includes('GOOGLE_OAUTH_CLIENT_ID') ||
          !names.includes('GOOGLE_OAUTH_CLIENT_SECRET')) {
        return error('Add the Google OAuth client ID and secret in AppDeploy secrets first.', 409);
      }
      const clientId = await secrets.readSecret('GOOGLE_OAUTH_CLIENT_ID');
      const state = crypto.randomUUID();
      const [savedId] = await db.tx.add('clipforge_streams', [{
        id: state,
        ownerId: ctx.user!.userId,
        title: 'Temporary YouTube authorization state',
        url: '',
        sourceType: 'youtube-oauth-state',
        createdAt: new Date().toISOString(),
        expiresAt: Date.now() + 10 * 60 * 1000,
      }]);
      if (!savedId) return error('Could not start YouTube authorization. Please retry.', 500);

      const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
      authUrl.searchParams.set('client_id', clientId);
      authUrl.searchParams.set('redirect_uri', YOUTUBE_CALLBACK_URL);
      authUrl.searchParams.set('response_type', 'code');
      authUrl.searchParams.set('scope', 'https://www.googleapis.com/auth/youtube.upload');
      authUrl.searchParams.set('state', state);
      authUrl.searchParams.set('include_granted_scopes', 'true');
      authUrl.searchParams.set('prompt', 'consent select_account');
      return json({ url: authUrl.toString(), callbackUrl: YOUTUBE_CALLBACK_URL });
    },
  ],
  'POST /api/youtube/oauth/exchange': [
    async ctx => {
      const body = (ctx.body || {}) as { code?: string; state?: string };
      const code = body.code;
      const state = body.state;
      if (!code || !state || !/^[0-9a-f-]{36}$/i.test(state))
        return error('The Google authorization response was invalid. Please reconnect.', 400);

      const [saved] = await db.get<OAuthState>('clipforge_streams', [state], { consistent: true });
      if (!saved || saved.sourceType !== 'youtube-oauth-state' ||
          saved.expiresAt < Date.now()) {
        if (saved) await db.delete('clipforge_streams', [state]);
        return error('The Google authorization expired. Please reconnect.', 400);
      }
      await db.delete('clipforge_streams', [state]);

      const names = await secrets.listSecretNames();
      if (!names.includes('GOOGLE_OAUTH_CLIENT_ID') ||
          !names.includes('GOOGLE_OAUTH_CLIENT_SECRET'))
        return error('The YouTube connection is not configured in AppDeploy secrets.', 409);

      const clientId = await secrets.readSecret('GOOGLE_OAUTH_CLIENT_ID');
      const clientSecret = await secrets.readSecret('GOOGLE_OAUTH_CLIENT_SECRET');
      const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          code,
          client_id: clientId,
          client_secret: clientSecret,
          redirect_uri: YOUTUBE_CALLBACK_URL,
          grant_type: 'authorization_code',
        }).toString(),
      });
      if (!tokenResponse.ok)
        return error('Google could not complete the token exchange. Check the redirect URI and reconnect.', 502);
      const tokenData = await tokenResponse.json() as {
        access_token?: string;
        expires_in?: number;
      };
      if (!tokenData.access_token)
        return error('Google did not return an upload access token. Please reconnect.', 502);
      return json({
        access_token: tokenData.access_token,
        expires_in: tokenData.expires_in || 3600,
      });
    },
  ],
  'GET /api/drive/oauth/start': [
    requireAuth(),
    async ctx => {
      const names = await secrets.listSecretNames();
      if (!names.includes('GOOGLE_OAUTH_CLIENT_ID') ||
          !names.includes('GOOGLE_OAUTH_CLIENT_SECRET')) {
        return error('Google OAuth credentials are not configured.', 409);
      }
      const clientId = await secrets.readSecret('GOOGLE_OAUTH_CLIENT_ID');
      const state = crypto.randomUUID();
      const [savedId] = await db.tx.add('clipforge_streams', [{
        id: state,
        ownerId: ctx.user!.userId,
        title: 'Temporary Google Drive authorization state',
        url: '',
        sourceType: 'drive-oauth-state',
        createdAt: new Date().toISOString(),
        expiresAt: Date.now() + 10 * 60 * 1000,
      }]);
      if (!savedId) return error('Could not start Google Drive authorization. Please retry.', 500);

      const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
      authUrl.searchParams.set('client_id', clientId);
      authUrl.searchParams.set('redirect_uri', YOUTUBE_CALLBACK_URL);
      authUrl.searchParams.set('response_type', 'code');
      authUrl.searchParams.set('scope', 'https://www.googleapis.com/auth/drive.readonly');
      authUrl.searchParams.set('state', state);
      authUrl.searchParams.set('access_type', 'offline');
      authUrl.searchParams.set('include_granted_scopes', 'true');
      authUrl.searchParams.set('prompt', 'consent select_account');
      return json({ url: authUrl.toString(), callbackUrl: YOUTUBE_CALLBACK_URL });
    },
  ],
  'POST /api/google/oauth/exchange': [
    requireAuth(),
    async ctx => {
      const body = (ctx.body || {}) as { code?: string; state?: string };
      const code = body.code;
      const state = body.state;
      if (!code || !state || !/^[0-9a-f-]{36}$/i.test(state))
        return error('The Google authorization response was invalid. Please reconnect.', 400);

      const [saved] = await db.get<OAuthState>('clipforge_streams', [state], { consistent: true });
      if (!saved || saved.ownerId !== ctx.user!.userId ||
          saved.sourceType !== 'drive-oauth-state' || saved.expiresAt < Date.now()) {
        if (saved && saved.ownerId === ctx.user!.userId) await db.delete('clipforge_streams', [state]);
        return error('The Google Drive authorization expired or did not match this account. Please reconnect.', 400);
      }
      await db.delete('clipforge_streams', [state]);

      const names = await secrets.listSecretNames();
      if (!names.includes('GOOGLE_OAUTH_CLIENT_ID') ||
          !names.includes('GOOGLE_OAUTH_CLIENT_SECRET'))
        return error('Google OAuth credentials are not configured.', 409);

      const clientId = await secrets.readSecret('GOOGLE_OAUTH_CLIENT_ID');
      const clientSecret = await secrets.readSecret('GOOGLE_OAUTH_CLIENT_SECRET');
      const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          code,
          client_id: clientId,
          client_secret: clientSecret,
          redirect_uri: YOUTUBE_CALLBACK_URL,
          grant_type: 'authorization_code',
        }).toString(),
      });
      if (!tokenResponse.ok)
        return error('Google could not complete the Drive token exchange. Check the OAuth redirect URI and reconnect.', 502);
      const tokenData = await tokenResponse.json() as {
        access_token?: string;
        expires_in?: number;
        scope?: string;
      };
      if (!tokenData.access_token)
        return error('Google did not return a Drive access token. Please reconnect.', 502);
      if (!tokenData.scope?.split(' ').includes('https://www.googleapis.com/auth/drive.readonly'))
        return error('Google did not grant read-only Drive access. Reconnect and approve the Drive permission.', 403);
      return json({
        integration: 'drive',
        access_token: tokenData.access_token,
        expires_in: tokenData.expires_in || 3600,
      });
    },
  ],
  'POST /api/drive/inbox': [
    requireAuth(),
    async ctx => {
      const body = (ctx.body || {}) as { accessToken?: string };
      if (!body.accessToken || body.accessToken.length > 5000)
        return error('Reconnect Google Drive to load the footage inbox.', 401);
      const url = new URL('https://www.googleapis.com/drive/v3/files');
      url.searchParams.set('q', "'" + READY_TO_CLIP_FOLDER_ID + "' in parents and trashed = false");
      url.searchParams.set('pageSize', '100');
      url.searchParams.set('orderBy', 'modifiedTime desc');
      url.searchParams.set('fields', 'files(id,name,mimeType,modifiedTime,size,webViewLink)');
      const response = await fetch(url.toString(), {
        headers: { Authorization: 'Bearer ' + body.accessToken },
      });
      if (!response.ok) {
        if (response.status === 401 || response.status === 403)
          return error('Google Drive did not allow access to the Ready to Clip folder. Check that the signed-in Google account can open that folder and reconnect.', response.status);
        return error('Google Drive could not list the footage inbox (' + response.status + ').', 502);
      }
      const payload = await response.json() as {
        files?: Array<{
          id: string;
          name: string;
          mimeType: string;
          modifiedTime?: string;
          size?: string;
          webViewLink?: string;
        }>;
      };
      const files = (payload.files || []).map(file => ({
        id: file.id,
        name: file.name,
        mimeType: file.mimeType,
        modifiedTime: file.modifiedTime || '',
        size: file.size || '',
        webViewLink: file.webViewLink || '',
        isVideo: file.mimeType.startsWith('video/'),
      }));
      return json({ folderConnected: true, folderId: READY_TO_CLIP_FOLDER_ID, files });
    },
  ],
  'POST /api/streams': [
    requireAuth(),
    async ctx => {
      const body = (ctx.body || {}) as {
        url?: string;
        title?: string;
        sourceType?: string;
      };
      if (
        !body.url ||
        !/^https:\/\/(www\.)?(youtube\.com|youtu\.be)\//i.test(body.url)
      )
        return error('Enter a valid YouTube URL.', 400);
      const ownerId = ctx.user!.userId;
      const [id] = await db.add('clipforge_streams', [
        {
          ownerId,
          title: (body.title || body.url).slice(0, 240),
          url: body.url,
          sourceType: body.sourceType || 'creator-authorized source',
          createdAt: new Date().toISOString(),
        },
      ]);
      if (!id) return error('Could not save this source. Please retry.', 500);
      return json({ id, saved: true }, 201);
    },
  ],
  'POST /api/analyze': [
    requireAuth(),
    async ctx => {
      const body = (ctx.body || {}) as MomentInput;
      if (
        !body.sourceTitle ||
        !body.sourceUrl ||
        !body.notes ||
        !body.startTime ||
        !body.endTime
      )
        return error(
          'Complete the source, time range and moment description.',
          400
        );
      if (
        !/^https:\/\/(www\.)?(youtube\.com|youtu\.be)\//i.test(body.sourceUrl)
      )
        return error('Enter a valid YouTube video URL.', 400);
      const result = await ai.generate({
        prompt:
          'Analyze this GTA 6 gameplay moment description and create YouTube Shorts metadata. Do not claim this footage has been captured or that performance is guaranteed. Use one category from: Funniest moments, Craziest moments, Epic gameplay, Fails & disasters, Streamer reactions, Best discoveries, Insane missions, Trending GTA 6 moments. Score 0-100 as an editorial estimate.\nSource: ' +
          body.sourceTitle +
          '\nCreator: ' +
          (body.creator || 'Not supplied') +
          '\nTime: ' +
          body.startTime +
          ' to ' +
          body.endTime +
          '\nMoment: ' +
          body.notes,
        schema: {
          type: 'object',
          properties: {
            title: { type: 'string' },
            category: { type: 'string' },
            score: { type: 'integer', minimum: 0, maximum: 100 },
            hook: { type: 'string' },
            description: { type: 'string' },
            hashtags: { type: 'array', items: { type: 'string' } },
          },
          required: [
            'title',
            'category',
            'score',
            'hook',
            'description',
            'hashtags',
          ],
        },
        maxTokens: 700,
        temperature: 0.65,
      });
      let metadata: {
        title: string;
        category: string;
        score: number;
        hook: string;
        description: string;
        hashtags: string[];
      };
      try {
        metadata = JSON.parse(result.text) as typeof metadata;
      } catch {
        return error(
          'The AI returned an unreadable result. Please retry the analysis.',
          502
        );
      }
      const record: SavedClip = {
        ownerId: ctx.user!.userId,
        title: String(metadata.title).slice(0, 120),
        category: String(metadata.category).slice(0, 80),
        score: Math.max(0, Math.min(100, Number(metadata.score) || 0)),
        hook: String(metadata.hook).slice(0, 220),
        description: String(metadata.description).slice(0, 1200),
        hashtags: Array.isArray(metadata.hashtags)
          ? metadata.hashtags.slice(0, 12).map(tag => String(tag).slice(0, 50))
          : [],
        startTime: body.startTime,
        endTime: body.endTime,
        sourceTitle: body.sourceTitle,
        sourceUrl: body.sourceUrl,
        creator: body.creator || '',
        status: 'needs review',
        createdAt: new Date().toISOString(),
      };
      const [id] = await db.add('clipforge_clips', [record]);
      if (!id)
        return error(
          'AI analysis completed but the clip idea could not be saved. Please retry.',
          500
        );
      return json({ id, clip: { ...record, id } }, 201);
    },
  ],
  'POST /api/shorts/suggest-moments': [
    requireAuth(),
    async ctx => {
      const body = (ctx.body || {}) as {
        transcript?: string;
        durationSeconds?: number;
        sourceTitle?: string;
      };
      const transcript = String(body.transcript || '').trim().slice(0, 12000);
      const durationSeconds = Number(body.durationSeconds);
      if (transcript.length < 30) return error('Add a more detailed timestamped transcript or notes.', 400);
      if (!/\b(?:\d{1,2}:)?\d{1,2}:\d{2}\b/.test(transcript))
        return error('Add timestamps such as 00:12 or 01:05 so moments can be located accurately.', 400);
      if (!Number.isFinite(durationSeconds) || durationSeconds <= 0)
        return error('Choose a valid local video file first.', 400);

      const result = await ai.generate({
        prompt:
          'You are ClipForge Smart Viral Ranking. Select up to five compelling 8-60 second moments from the supplied timestamped transcript/notes. Use ONLY explicit timestamps; never invent or estimate times. Rank each candidate using evidence in the text: hookStrength (25%), humour (15%), surprise (20%), emotion (15%), clarity (10%) and replayPotential (15%). Give each dimension a 0-100 score, explain the evidence briefly, and avoid generic or repetitive moments. Do not reward misleading, harmful or context-stripped moments. If evidence is insufficient, return an empty moments array.\nSource title: ' +
          String(body.sourceTitle || 'Authorised video').slice(0, 200) +
          '\nSource duration in seconds: ' + durationSeconds +
          '\nTimestamped transcript/notes:\n' + transcript,
        schema: {
          type: 'object',
          properties: {
            moments: {
              type: 'array',
              maxItems: 5,
              items: {
                type: 'object',
                properties: {
                  startSeconds: { type: 'number' },
                  endSeconds: { type: 'number' },
                  label: { type: 'string' },
                  reason: { type: 'string' },
                  score: { type: 'integer', minimum: 0, maximum: 100 },
                  hookStrength: { type: 'integer', minimum: 0, maximum: 100 },
                  humour: { type: 'integer', minimum: 0, maximum: 100 },
                  surprise: { type: 'integer', minimum: 0, maximum: 100 },
                  emotion: { type: 'integer', minimum: 0, maximum: 100 },
                  clarity: { type: 'integer', minimum: 0, maximum: 100 },
                  replayPotential: { type: 'integer', minimum: 0, maximum: 100 }
                },
                required: ['startSeconds', 'endSeconds', 'label', 'reason', 'score', 'hookStrength', 'humour', 'surprise', 'emotion', 'clarity', 'replayPotential']
              }
            }
          },
          required: ['moments']
        },
        maxTokens: 900,
        temperature: 0.25,
        cache: true
      });
      let suggestions: { moments: Array<{
        startSeconds: number;
        endSeconds: number;
        label: string;
        reason: string;
        score: number;
        hookStrength: number;
        humour: number;
        surprise: number;
        emotion: number;
        clarity: number;
        replayPotential: number;
      }> };
      try {
        suggestions = JSON.parse(result.text) as typeof suggestions;
      } catch {
        return error('AI could not format the moment suggestions. Please retry.', 502);
      }
      const moments = (suggestions.moments || []).map(moment => ({
        startSeconds: Math.max(0, Number(moment.startSeconds) || 0),
        endSeconds: Math.min(durationSeconds, Number(moment.endSeconds) || 0),
        label: String(moment.label || 'Suggested highlight').slice(0, 100),
        reason: String(moment.reason || '').slice(0, 240),
        hookStrength: Math.max(0, Math.min(100, Number(moment.hookStrength) || 0)),
        humour: Math.max(0, Math.min(100, Number(moment.humour) || 0)),
        surprise: Math.max(0, Math.min(100, Number(moment.surprise) || 0)),
        emotion: Math.max(0, Math.min(100, Number(moment.emotion) || 0)),
        clarity: Math.max(0, Math.min(100, Number(moment.clarity) || 0)),
        replayPotential: Math.max(0, Math.min(100, Number(moment.replayPotential) || 0)),
        score: Math.round(
          Math.max(0, Math.min(100, Number(moment.hookStrength) || 0)) * 0.25 +
          Math.max(0, Math.min(100, Number(moment.humour) || 0)) * 0.15 +
          Math.max(0, Math.min(100, Number(moment.surprise) || 0)) * 0.20 +
          Math.max(0, Math.min(100, Number(moment.emotion) || 0)) * 0.15 +
          Math.max(0, Math.min(100, Number(moment.clarity) || 0)) * 0.10 +
          Math.max(0, Math.min(100, Number(moment.replayPotential) || 0)) * 0.15
        )
      })).filter(moment =>
        moment.startSeconds >= 0 &&
        moment.endSeconds > moment.startSeconds &&
        moment.endSeconds - moment.startSeconds >= 8 &&
        moment.endSeconds - moment.startSeconds <= 60 &&
        moment.endSeconds <= durationSeconds
      ).sort((a, b) => b.score - a.score).slice(0, 5);
      return json({ moments, sourceDuration: durationSeconds });
    }
  ],
  'POST /api/shorts/commentary': [
    requireAuth(),
    async ctx => {
      const body = (ctx.body || {}) as {
        sourceTitle?: string;
        transcript?: string;
        momentLabel?: string;
        reason?: string;
        startSeconds?: number;
        endSeconds?: number;
      };
      const transcript = String(body.transcript || '').trim().slice(0, 12000);
      const sourceTitle = String(body.sourceTitle || 'Authorised video').slice(0, 200);
      const momentLabel = String(body.momentLabel || 'Selected highlight').slice(0, 160);
      if (transcript.length < 30) return error('Add a timestamped transcript or detailed notes before generating commentary.', 400);
      const result = await ai.generate({
        prompt:
          'Create original, clearly transformative YouTube Shorts commentary for an editor working with footage they own or are authorised to use. Base every factual statement on the supplied transcript/notes. Do not invent dialogue, events, quotes, reactions, or claims. Do not imitate a real creator or their voice. Avoid deceptive hooks, keyword stuffing, repetitive templates and requests to manipulate engagement. Make the commentary add context, humour or a distinct point of view rather than merely restating the source. Provide a short opening hook, a natural 1-3 sentence voiceover, 2-4 on-screen text beats, an optional genuine question for viewers, and an alternate hook.\nSource: ' +
          sourceTitle +
          '\nSelected moment: ' + momentLabel +
          '\nMoment time range: ' + Number(body.startSeconds || 0) + ' to ' + Number(body.endSeconds || 0) + ' seconds\nWhy it was selected: ' +
          String(body.reason || '').slice(0, 300) +
          '\nTranscript / notes:\n' + transcript,
        schema: {
          type: 'object',
          properties: {
            openingHook: { type: 'string' },
            voiceover: { type: 'string' },
            onScreenBeats: { type: 'array', minItems: 2, maxItems: 4, items: { type: 'string' } },
            viewerQuestion: { type: 'string' },
            alternateHook: { type: 'string' },
            originalityNote: { type: 'string' }
          },
          required: ['openingHook', 'voiceover', 'onScreenBeats', 'viewerQuestion', 'alternateHook', 'originalityNote']
        },
        maxTokens: 700,
        temperature: 0.7,
        cache: true
      });
      try {
        const commentary = JSON.parse(result.text) as {
          openingHook: string;
          voiceover: string;
          onScreenBeats: string[];
          viewerQuestion: string;
          alternateHook: string;
          originalityNote: string;
        };
        return json({ commentary });
      } catch {
        return error('AI could not format the commentary. Please try again.', 502);
      }
    }
  ],
  'POST /api/shorts/prepare': [
    requireAuth(),
    async ctx => {
      const body = (ctx.body || {}) as {
        sourceTitle?: string;
        creator?: string;
        startTime?: string;
        endTime?: string;
        transcript?: string;
      };
      if (!body.sourceTitle?.trim() || !body.transcript?.trim()) {
        return error('Add a source title and transcript or a detailed moment description.', 400);
      }
      if (body.transcript.length > 12000) {
        return error('Keep the transcript under 12,000 characters.', 400);
      }
      const result = await ai.generate({
        prompt:
          'You are ClipForge AI Shorts Editor. Prepare an editing blueprint for an authorised GTA 6 video. Use only information in the supplied transcript; do not invent events or claim a rendered video exists. Create a strong but accurate hook, a concise Shorts title, description, hashtags, vertical 9:16 edit instructions, and timed caption segments. Caption segments must be in chronological order, readable on a phone, usually 2-7 words each, and cover the spoken/story beats without adding dialogue. Use timestamps relative to the clip start in seconds. Target duration 20-60 seconds.\nSource: ' +
          body.sourceTitle +
          '\nCreator: ' + (body.creator || 'Not supplied') +
          '\nSource time range: ' + (body.startTime || 'Not supplied') + ' to ' + (body.endTime || 'Not supplied') +
          '\nTranscript / moment notes:\n' + body.transcript,
        schema: {
          type: 'object',
          properties: {
            viralScore: { type: 'integer', minimum: 0, maximum: 100 },
            hook: { type: 'string' },
            title: { type: 'string' },
            description: { type: 'string' },
            hashtags: { type: 'array', items: { type: 'string' } },
            editNotes: { type: 'array', items: { type: 'string' } },
            captions: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  start: { type: 'number' },
                  end: { type: 'number' },
                  text: { type: 'string' }
                },
                required: ['start', 'end', 'text']
              }
            }
          },
          required: ['viralScore', 'hook', 'title', 'description', 'hashtags', 'editNotes', 'captions']
        },
        maxTokens: 1600,
        temperature: 0.55
      });
      let plan: {
        viralScore: number;
        hook: string;
        title: string;
        description: string;
        hashtags: string[];
        editNotes: string[];
        captions: Array<{ start: number; end: number; text: string }>;
      };
      try {
        plan = JSON.parse(result.text) as typeof plan;
      } catch {
        return error('The AI could not format the Shorts plan. Please try again.', 502);
      }
      plan.viralScore = Math.max(0, Math.min(100, Number(plan.viralScore) || 0));
      plan.captions = (plan.captions || []).slice(0, 80).map(line => ({
        start: Math.max(0, Number(line.start) || 0),
        end: Math.max(0, Number(line.end) || 0),
        text: String(line.text || '').slice(0, 100)
      })).filter(line => line.end > line.start && line.text);
      return json({
        plan,
        sourceTitle: body.sourceTitle,
        creator: body.creator || '',
        sourceStart: body.startTime || '',
        sourceEnd: body.endTime || '',
        generatedAt: new Date().toISOString(),
        rendered: false
      });
    }
  ],
  'POST /api/clips/:id/approve': [
    requireAuth(),
    async ctx => {
      const [clip] = await db.get<SavedClip>(
        'clipforge_clips',
        [ctx.params.id],
        { consistent: true }
      );
      if (!clip || clip.ownerId !== ctx.user!.userId)
        return error('Clip not found.', 404);
      const [updated] = await db.tx.update(
        'clipforge_clips',
        [
          {
            id: ctx.params.id,
            record: { status: 'approved' },
          },
        ],
        { patch: true }
      );
      if (!updated) return error('Could not approve this clip.', 409);
      return json({ approved: true });
    },
  ],
};

export const handler = router(routes);
